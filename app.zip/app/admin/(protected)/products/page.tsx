import Link from "next/link";

import { AdminPageShell } from "@/components/admin/admin-page-shell";
import { Button } from "@/components/ui/button";
import { ProductTable } from "@/features/admin/products/components/list/product-table";
import { parseProductsPageParams } from "@/features/admin/products/navigation";
import { mapProductTableItem } from "@/features/admin/products/list/mappers/server";
import { getAdminProductsFeed } from "@/features/admin/products/list/queries/get-admin-products-feed.query";
import { listAdminProducts } from "@/features/admin/products/list/queries/list-admin-products.query";
import { listProductFilterCategories } from "@/features/admin/products/list/queries/list-product-filter-categories.query";

export default async function AdminProductsPage() {
  const params = parseProductsPageParams(undefined);

  const [rawProducts, categoryOptions, initialMobileFeed] = await Promise.all([
    listAdminProducts(params),
    listProductFilterCategories(),
    getAdminProductsFeed({
      limit: 12,
      cursor: null,
      ...(params.search.trim().length > 0 ? { search: params.search } : {}),
    }),
  ]);

  const products = rawProducts.map(mapProductTableItem);

  return (
    <AdminPageShell
      mode="viewport"
      variant="tool"
      headerVariant="overview"
      headerVisibility="desktop"
      eyebrow="Catalogue"
      title="Produits"
      description="Pilotez le catalogue et affinez rapidement la liste."
      pageTitleAction={{ label: "Nouveau produit", href: "/admin/products/new" }}
      actions={
        <Button asChild size="sm" className="hidden w-full lg:inline-flex lg:min-w-40 lg:w-auto">
          <Link href="/admin/products/new">Nouveau produit</Link>
        </Button>
      }
      breadcrumbs={[{ label: "Accueil", href: "/admin" }, { label: "Produits" }]}
      viewportClassName={[
        "h-[calc(100svh-4.5rem+env(safe-area-inset-bottom))]",
        "supports-[height:100dvh]:h-[calc(100dvh-4.5rem+env(safe-area-inset-bottom))]",
        "md:gap-6 md:h-[calc(100svh-5rem+env(safe-area-inset-bottom))]",
        "md:supports-[height:100dvh]:h-[calc(100dvh-5rem+env(safe-area-inset-bottom))]",
        "lg:h-[calc(100svh-6.5rem)] lg:supports-[height:100dvh]:h-[calc(100dvh-6.5rem)]",
        "[@media(max-height:480px)]:h-[calc(100svh-3.75rem+env(safe-area-inset-bottom))]",
        "[@media(max-height:480px)]:supports-[height:100dvh]:h-[calc(100dvh-3.75rem+env(safe-area-inset-bottom))]",
        "[@media(max-height:480px)]:gap-1.5",
      ].join(" ")}
      headerClassName="border-b border-border-soft/80 pt-2 pb-1.5 lg:pt-3 lg:pb-3"
      headerContentClassName="px-4 md:px-6 lg:px-0"
      bodyClassName="flex min-h-0 flex-1 flex-col overflow-hidden"
      scrollMode="nested"
    >
      <ProductTable
        products={products}
        categoryOptions={categoryOptions}
        initialMobileFeed={initialMobileFeed}
      />
    </AdminPageShell>
  );
}
