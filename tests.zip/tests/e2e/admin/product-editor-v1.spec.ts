import { expect, test, type Page } from "@playwright/test";
import { loginAsSeedAdmin } from "./admin-auth";

function createUniqueIdentity(prefix: string): { name: string; slug: string } {
  const suffix = `${Date.now()}-${Math.floor(Math.random() * 10_000)}`;
  return {
    name: `${prefix} ${suffix}`,
    slug: `${prefix.toLowerCase().replace(/\s+/g, "-")}-${suffix}`,
  };
}

async function createDraftProduct(page: Page, input: { name: string; slug: string }): Promise<void> {
  await page.goto("/admin/products/new", { waitUntil: "domcontentloaded" });
  await page.getByLabel("Nom du produit").fill(input.name);
  await page.getByLabel("Slug").fill(input.slug);
  await page.getByRole("button", { name: "Créer le produit" }).click();

  await page.waitForURL(new RegExp(`/admin/products/${input.slug}(?:/edit)?(?:\\?.*)?$`), {
    timeout: 20_000,
  });

  if (!page.url().includes("/edit")) {
    await page.goto(`/admin/products/${input.slug}/edit`, { waitUntil: "domcontentloaded" });
  }
}

async function openEditor(page: Page, slug: string): Promise<void> {
  await page.goto(`/admin/products/${slug}/edit`, { waitUntil: "domcontentloaded" });
  await expect(page).toHaveURL(new RegExp(`/admin/products/${slug}/edit(?:\\?.*)?$`));
}

async function clickEditorTab(page: Page, tabName: string): Promise<void> {
  const tab = page.getByRole("tab", { name: tabName, exact: true }).first();
  await expect(tab).toBeVisible();
  await tab.click();
}

test.describe.serial("admin editor product v1 smoke", () => {
  let editorProduct: { name: string; slug: string } | null = null;
  let targetRelatedProduct: { name: string; slug: string } | null = null;
  let variantSku = "";

  test("ouvre /edit, navigue tabs, vérifie responsive et états vides", async ({ page }) => {
    targetRelatedProduct = createUniqueIdentity("Produit Cible E2E");
    editorProduct = createUniqueIdentity("Produit Éditeur E2E");

    await loginAsSeedAdmin(page);
    await createDraftProduct(page, targetRelatedProduct);
    await createDraftProduct(page, editorProduct);
    await openEditor(page, editorProduct.slug);

    const tabs = [
      "Général",
      "Variantes",
      "Tarification",
      "Disponibilité",
      "Stock",
      "Médias",
      "Catégories",
      "Produits liés",
      "SEO",
    ] as const;

    for (const tabName of tabs) {
      await clickEditorTab(page, tabName);
    }

    await clickEditorTab(page, "Produits liés");
    await expect(page.getByText("Aucune relation enregistrée pour ce produit.")).toBeVisible();

    await clickEditorTab(page, "Médias");
    await expect(page.getByText("Aucune image principale du produit n'est définie.")).toBeVisible();

    await page.setViewportSize({ width: 390, height: 844 });
    await openEditor(page, editorProduct.slug);
    await clickEditorTab(page, "Médias");

    const hasHorizontalOverflow = await page.evaluate(() => {
      return document.documentElement.scrollWidth > document.documentElement.clientWidth + 1;
    });
    expect(hasHorizontalOverflow).toBeFalsy();

    await page.getByRole("button", { name: "Ouvrir les actions des images" }).click();
    await page.getByRole("menuitem", { name: "Associer depuis la bibliothèque" }).click();
    await expect(page.getByRole("heading", { name: "Médiathèque" })).toBeVisible();
    await expect(page.getByRole("dialog")).toHaveCount(1);
    await page.getByRole("button", { name: "Annuler" }).click();
    await expect(page.getByRole("heading", { name: "Médiathèque" })).toHaveCount(0);
  });

  test("modifie Général puis sauvegarde sans reload manuel", async ({ page }) => {
    if (!editorProduct) {
      test.fail(true, "Produit éditeur non initialisé");
      return;
    }

    await loginAsSeedAdmin(page);
    await openEditor(page, editorProduct.slug);
    await clickEditorTab(page, "Général");

    const generalForm = page.locator("form").filter({ has: page.getByLabel("Nom du produit") }).first();
    const updatedName = `${editorProduct.name} (MAJ)`;

    await generalForm.getByLabel("Nom du produit").fill(updatedName);
    await generalForm.getByRole("button", { name: "Enregistrer" }).click();

    await expect(page.getByText("Mise à jour effectuée.")).toBeVisible();
    await expect(generalForm.getByLabel("Nom du produit")).toHaveValue(updatedName);
  });

  test("crée puis modifie une variante et constate le refresh UI", async ({ page }) => {
    if (!editorProduct) {
      test.fail(true, "Produit éditeur non initialisé");
      return;
    }

    variantSku = `SKU-E2E-${Date.now()}`;
    const updatedSku = `${variantSku}-UPD`;

    await loginAsSeedAdmin(page);
    await openEditor(page, editorProduct.slug);
    await clickEditorTab(page, "Variantes");

    await page.getByRole("button", { name: "Ajouter une variante" }).click();
    await expect(page.getByRole("dialog")).toHaveCount(1);

    const createDialog = page.getByRole("dialog").first();
    await createDialog.getByLabel("Nom").fill("Variante test E2E");
    await createDialog.getByLabel("SKU").fill(variantSku);
    await createDialog.getByRole("button", { name: "Créer" }).click();

    await expect(page.getByRole("dialog")).toHaveCount(0);
    await expect(page.getByText(variantSku)).toBeVisible();

    const variantCard = page.locator("article").filter({ hasText: variantSku }).first();
    await variantCard.getByRole("button", { name: "Modifier" }).click();
    await expect(page.getByRole("dialog")).toHaveCount(1);

    const editDialog = page.getByRole("dialog").first();
    await editDialog.getByLabel("SKU").fill(updatedSku);
    await editDialog.getByRole("button", { name: "Enregistrer" }).click();

    await expect(page.getByRole("dialog")).toHaveCount(0);
    await expect(page.getByText(updatedSku)).toBeVisible();
    await expect(page.getByText(variantSku)).toHaveCount(0);
    variantSku = updatedSku;
  });

  test("modifie la Tarification", async ({ page }) => {
    if (!editorProduct) {
      test.fail(true, "Produit éditeur non initialisé");
      return;
    }

    await loginAsSeedAdmin(page);
    await openEditor(page, editorProduct.slug);
    await clickEditorTab(page, "Tarification");

    await expect(page.getByLabel("Prix de vente").first()).toBeVisible();
    await expect(page.getByText("Prix appliqué")).toBeVisible();
    await expect(page.getByText("Prix du produit")).toBeVisible();

    const targetPrice = "129.90";
    const priceField = page.getByLabel("Prix de vente").first();
    await priceField.fill(targetPrice);
    await page.getByRole("button", { name: "Enregistrer" }).click();

    await expect(page.getByText("Tarification mise à jour.")).toBeVisible();
    await expect(priceField).toHaveValue(targetPrice);
  });

  test("modifie Produits liés sans reload manuel", async ({ page }) => {
    if (!editorProduct || !targetRelatedProduct) {
      test.fail(true, "Produits de test non initialisés");
      return;
    }

    await loginAsSeedAdmin(page);
    await openEditor(page, editorProduct.slug);
    await clickEditorTab(page, "Produits liés");

    await expect(page.getByText("Aucune relation enregistrée pour ce produit.")).toBeVisible();

    const addSection = page.locator("section").filter({ hasText: "Ajouter une relation" }).first();
    await addSection.getByRole("combobox").first().click();
    await page
      .getByRole("option", { name: new RegExp(targetRelatedProduct.name) })
      .first()
      .click();
    await addSection.getByRole("button", { name: "Ajouter" }).click();

    await page.getByRole("button", { name: "Enregistrer" }).click();
    await expect(page.getByText("Mise à jour effectuée.")).toBeVisible();
    await expect(page.getByText(targetRelatedProduct.name)).toBeVisible();
  });

  test("modifie Disponibilité + Stock pour une variante sans records initiaux", async ({ page }) => {
    if (!editorProduct || variantSku.length === 0) {
      test.fail(true, "Variante de test non initialisée");
      return;
    }

    await loginAsSeedAdmin(page);
    await openEditor(page, editorProduct.slug);

    await clickEditorTab(page, "Disponibilité");
    const availabilityCard = page.locator("div.rounded-xl").filter({ hasText: variantSku }).first();
    await availabilityCard.getByRole("combobox").first().click();
    await page.getByRole("option", { name: "Disponible à la vente" }).click();
    await page.getByRole("button", { name: "Enregistrer" }).click();
    await expect(page.getByText("Disponibilité mise à jour.")).toBeVisible();
    await expect(page.getByText("Disponible à la vente")).toBeVisible();

    await clickEditorTab(page, "Stock");
    const stockCard = page.locator("div.rounded-xl").filter({ hasText: variantSku }).first();
    await expect(stockCard.getByText("État inventaire:")).toBeVisible();
    await expect(stockCard.getByText("À créer")).toBeVisible();

    await stockCard.getByLabel("Stock physique").fill("7");
    await stockCard.getByLabel("Stock réservé").fill("2");
    await page.getByRole("button", { name: "Enregistrer" }).click();

    await expect(page.getByText("Stock mis à jour.")).toBeVisible();
    await expect(stockCard.getByText("Enregistré")).toBeVisible();
    await expect(stockCard.getByText("Stock disponible:")).toBeVisible();
    await expect(stockCard.getByText("5")).toBeVisible();
  });
});
