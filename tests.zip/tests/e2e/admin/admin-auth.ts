import { expect, type Page } from "@playwright/test";

const SEEDED_ADMIN_EMAIL = "admin@creatyss.local";
const SEEDED_ADMIN_PASSWORD = "AdminDev123!";
const ADMIN_LOGIN_PATH = "/admin/login";
const ADMIN_HOME_URL_PATTERN = /\/admin(?:\/.*)?$/;
const ADMIN_LOGOUT_BUTTON_LABEL = "Se déconnecter";
const ADMIN_LOGIN_MAX_ATTEMPTS = 3;
const ADMIN_LOGIN_NAVIGATION_TIMEOUT_MS = 30_000;
const ADMIN_LOGIN_SUBMIT_TIMEOUT_MS = 15_000;
const ADMIN_LOGIN_RETRY_DELAY_MS = 1_000;
const ADMIN_READY_CHECK_TIMEOUT_MS = 1_500;

function isRecoverableAdminLoginNavigationErrorMessage(message: string): boolean {
  return message.includes("ERR_ABORTED") || message.includes("Timeout");
}

async function waitForAdminLoginForm(page: Page): Promise<void> {
  await expect(page.getByLabel("Email")).toBeVisible();
  await expect(page.getByLabel("Mot de passe")).toBeVisible();
  await expect(page.locator("form button[type='submit']").first()).toBeVisible();
}

async function isAdminShellVisible(page: Page): Promise<boolean> {
  const shellCandidates = [
    page.getByRole("button", { name: ADMIN_LOGOUT_BUTTON_LABEL }).first(),
    page.getByRole("link", { name: "Produits" }).first(),
  ];

  for (const candidate of shellCandidates) {
    try {
      await candidate.waitFor({ state: "visible", timeout: ADMIN_READY_CHECK_TIMEOUT_MS });
      return true;
    } catch {
      continue;
    }
  }

  return false;
}

async function waitForAdminShell(page: Page): Promise<void> {
  await expect(page).toHaveURL(ADMIN_HOME_URL_PATTERN);
  const shellIsVisible = await isAdminShellVisible(page);
  expect(shellIsVisible).toBeTruthy();
}

async function gotoAdminLogin(page: Page): Promise<void> {
  for (let attempt = 0; attempt < ADMIN_LOGIN_MAX_ATTEMPTS; attempt += 1) {
    try {
      await page.goto(ADMIN_LOGIN_PATH, {
        timeout: ADMIN_LOGIN_NAVIGATION_TIMEOUT_MS,
        waitUntil: "domcontentloaded",
      });
      return;
    } catch (error) {
      const isLastAttempt = attempt === ADMIN_LOGIN_MAX_ATTEMPTS - 1;
      const recoverable =
        error instanceof Error && isRecoverableAdminLoginNavigationErrorMessage(error.message);

      if (!recoverable || isLastAttempt) {
        throw error;
      }

      await page.waitForTimeout(ADMIN_LOGIN_RETRY_DELAY_MS);
    }
  }
}

export async function loginAsSeedAdmin(page: Page): Promise<void> {
  await gotoAdminLogin(page);

  const shellAlreadyVisible = await isAdminShellVisible(page);
  if (shellAlreadyVisible) {
    await waitForAdminShell(page);
    return;
  }

  await waitForAdminLoginForm(page);

  await page.getByLabel("Email").fill(SEEDED_ADMIN_EMAIL);
  await page.getByLabel("Mot de passe").fill(SEEDED_ADMIN_PASSWORD);

  await Promise.all([
    page.waitForURL(ADMIN_HOME_URL_PATTERN, {
      timeout: ADMIN_LOGIN_SUBMIT_TIMEOUT_MS,
    }),
    page.locator("form button[type='submit']").first().click(),
  ]);

  await waitForAdminShell(page);
}
