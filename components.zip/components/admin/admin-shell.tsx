"use client";

import type { ReactNode } from "react";

import { AdminPageTitleProvider } from "@/components/admin/admin-page-title-context";
import { AdminSidebar } from "@/components/admin/admin-sidebar";
import { AdminMobileBottomNav, AdminTopbar } from "@/components/admin/navigation";
import { SidebarInset, SidebarProvider } from "@/components/ui/sidebar";

type AdminShellProps = {
  children: ReactNode;
  displayName: string;
  email: string;
};

export function AdminShell({ children, displayName, email }: AdminShellProps) {
  return (
    <AdminPageTitleProvider>
      <SidebarProvider
        data-admin-shell="true"
        className="h-svh overflow-hidden supports-[height:100dvh]:h-dvh"
      >
        <div className="hidden lg:block [@media(max-height:480px)]:hidden">
          <AdminSidebar displayName={displayName} email={email} />
        </div>

        <SidebarInset className="min-w-0 bg-background">
          <AdminTopbar />

          <div className="min-h-0 flex-1 overflow-hidden">
            <div
              className={[
                "mx-auto flex w-full max-w-7xl min-w-0 flex-col",
                "gap-4  md:gap-6 md:p-6",
                "pb-[calc(3.5rem+env(safe-area-inset-bottom))] lg:pb-6",
                "[@media(max-height:480px)]:gap-2",
                "[@media(max-height:480px)]:p-0",
                "[@media(max-height:480px)]:pb-[calc(3rem+env(safe-area-inset-bottom))]",
              ].join(" ")}
            >
              {children}
            </div>
          </div>

          <AdminMobileBottomNav />
        </SidebarInset>
      </SidebarProvider>
    </AdminPageTitleProvider>
  );
}
