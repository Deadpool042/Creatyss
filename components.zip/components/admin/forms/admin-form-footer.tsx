import type { ReactNode } from "react";

import { AdminFormActions } from "@/components/admin/forms/admin-form-actions";
import { cn } from "@/lib/utils";

type AdminFormFooterProps = Readonly<{
  children: ReactNode;
  className?: string;
  actionsClassName?: string;
}>;

export function AdminFormFooter({ children, className, actionsClassName }: AdminFormFooterProps) {
  return (
    <div
      className={cn(
        [
          "site-header-blur w-full shrink-0",
          "border-t border-shell-border/60",
          "px-4 py-2",
          "md:px-6 md:py-2.5",
          "[@media(max-height:480px)]:py-1.5",
          "lg:shadow-none",
        ].join(" "),
        className
      )}
    >
      <div className="flex w-full items-center">
        <AdminFormActions
          className={cn("flex w-full items-center justify-between gap-3", actionsClassName)}
        >
          {children}
        </AdminFormActions>
      </div>
    </div>
  );
}
