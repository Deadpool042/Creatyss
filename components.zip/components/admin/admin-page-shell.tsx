import type { ReactNode } from "react";

import { AdminPageHeader } from "@/components/admin/admin-page-header";
import { AdminPageTitle } from "@/components/admin/admin-page-title";
import type { AppBreadcrumbItem } from "@/components/shared/breadcrumbs";
import { ViewportScrollArea } from "@/components/shared/viewport-scroll-area";
import { cn } from "@/lib/utils";

type AdminPageShellLayout = "overview" | "tool";
type AdminPageShellScroll = "page" | "content";

type AdminPageShellLinkAction = {
  label: string;
  href: string;
  ariaLabel?: string;
};

type AdminPageShellProps = {
  title: string;
  children: ReactNode;

  eyebrow?: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  breadcrumbs?: ReadonlyArray<AppBreadcrumbItem>;

  layout?: AdminPageShellLayout;
  scroll?: AdminPageShellScroll;

  navigation?: AdminPageShellLinkAction;
  topbarAction?: ReactNode;

  headerVisibility?: "all" | "desktop";
  compactMobileTitle?: boolean;
  hideEyebrowOnLowHeight?: boolean;
  hideDescriptionOnMobile?: boolean;

  className?: string;
  viewportClassName?: string;
  headerClassName?: string;
  bodyClassName?: string;
  contentClassName?: string;
};

export function AdminPageShell({
  title,
  children,
  eyebrow,
  description,
  actions,
  breadcrumbs = [],
  layout = "overview",
  scroll,
  navigation,
  topbarAction,
  headerVisibility = "all",
  compactMobileTitle = false,
  hideEyebrowOnLowHeight = false,
  hideDescriptionOnMobile = false,
  className,
  viewportClassName,
  headerClassName,
  bodyClassName,
  contentClassName,
}: AdminPageShellProps) {
  const resolvedScroll: AdminPageShellScroll = scroll ?? (layout === "tool" ? "content" : "page");

  const isTool = layout === "tool";
  const usesNestedScroll = resolvedScroll === "content";

  return (
    <>
      <AdminPageTitle
        title={title}
        {...(navigation ? { navigation } : {})}
        {...(topbarAction ? { actionNode: topbarAction } : {})}
      />

      <ViewportScrollArea
        className={cn(
          isTool && "gap-4 lg:gap-6 [@media(max-height:480px)]:gap-3",
          className,
          viewportClassName
        )}
        headerClassName={cn(
          isTool &&
            "border-b border-border-soft/80 pb-2.5 sm:pb-5 lg:pb-5 [@media(max-height:480px)]:pb-2",
          headerVisibility === "desktop" && "hidden lg:block",
          headerClassName
        )}
        bodyClassName={cn("flex min-h-0 flex-1 flex-col overflow-hidden", bodyClassName)}
        scrollMode={usesNestedScroll ? "nested" : "area"}
        header={
          <AdminPageHeader
            actions={actions}
            breadcrumbs={breadcrumbs}
            compactMobileTitle={compactMobileTitle}
            description={description}
            eyebrow={eyebrow}
            hideDescriptionOnMobile={hideDescriptionOnMobile}
            hideEyebrowOnLowHeight={hideEyebrowOnLowHeight}
            title={title}
            variant={layout}
          />
        }
      >
        {usesNestedScroll ? (
          <div className={cn("min-h-0 flex-1 overflow-hidden", contentClassName)}>{children}</div>
        ) : (
          children
        )}
      </ViewportScrollArea>
    </>
  );
}
