import type { ReactNode } from "react";

import { AppBreadcrumbs, type AppBreadcrumbItem } from "@/components/shared/breadcrumbs";
import { cn } from "@/lib/utils";

type AdminPageHeaderProps = {
  eyebrow?: ReactNode;
  title?: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  breadcrumbs?: ReadonlyArray<AppBreadcrumbItem>;
  compactMobileTitle?: boolean;
  hideEyebrowOnLowHeight?: boolean;
  hideDescriptionOnMobile?: boolean;
  variant?: "overview" | "page" | "tool";
  className?: string;
};

export function AdminPageHeader({
  eyebrow,
  title,
  description,
  actions,
  breadcrumbs = [],
  compactMobileTitle = false,
  hideEyebrowOnLowHeight = false,
  hideDescriptionOnMobile = false,
  variant = "overview",
  className,
}: AdminPageHeaderProps) {
  const resolvedVariant = variant === "page" ? "overview" : variant;
  const isTool = resolvedVariant === "tool";

  return (
    <div
      className={cn(
        isTool
          ? "flex flex-col gap-1.5 sm:gap-2.5 [@media(max-height:480px)]:gap-1"
          : "flex flex-col gap-2.5 sm:gap-4 [@media(max-height:480px)]:gap-1.5",
        className
      )}
    >
      {breadcrumbs.length > 0 ? (
        <AppBreadcrumbs
          className={cn(
            "hidden text-xs text-muted-foreground [@media(max-height:480px)]:hidden",
            isTool ? "lg:block" : "md:block"
          )}
          items={breadcrumbs}
        />
      ) : null}

      <div
        className={cn(
          "flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between [@media(max-height:480px)]:gap-1.5",
          isTool && "gap-2 sm:gap-3"
        )}
      >
        <div className="min-w-0 flex-1">
          {eyebrow ? (
            <p
              className={cn(
                "mb-1.5 text-[11px] font-semibold uppercase tracking-[0.14em] text-primary",
                hideEyebrowOnLowHeight && "[@media(max-height:480px)]:hidden",
                isTool && "hidden lg:block"
              )}
            >
              {eyebrow}
            </p>
          ) : null}

          {title ? (
            <h1
              className={[
                "font-semibold tracking-tight leading-tight text-foreground",
                isTool
                  ? "text-[1.75rem] lg:text-3xl"
                  : compactMobileTitle
                    ? "text-2xl lg:text-3xl"
                    : "text-3xl",
              ].join(" ")}
            >
              {title}
            </h1>
          ) : null}

          {description ? (
            <p
              className={cn(
                "mt-1.5 max-w-3xl text-sm leading-5 text-muted-foreground sm:text-base sm:leading-6 [@media(max-height:480px)]:hidden",
                hideDescriptionOnMobile && "hidden sm:block",
                isTool && "hidden lg:block"
              )}
            >
              {description}
            </p>
          ) : null}
        </div>

        {actions ? (
          <div
            className={cn(
              "flex w-full shrink-0 items-center sm:w-auto sm:justify-end",
              isTool && "hidden lg:flex"
            )}
          >
            {actions}
          </div>
        ) : null}
      </div>
    </div>
  );
}
