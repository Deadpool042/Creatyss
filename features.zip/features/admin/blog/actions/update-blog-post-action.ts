"use server";

import { redirect } from "next/navigation";
import { updateAdminBlogPost } from "../services";
import { AdminBlogServiceError } from "../types";
import { listAdminMediaAssets } from "@/features/admin/media";
import { normalizeBlogPostSlug } from "@/entities/blog/blog-post-input";
import { getBlogPostPublishability } from "@/entities/blog/blog-post-publishability";
import { BlogPostFormSchema, parseImageSelection } from "../schemas/blog-post-form-schema";

function normalizeBlogPostId(value: FormDataEntryValue | null): string | null {
  if (typeof value !== "string") {
    return null;
  }

  const normalizedValue = value.trim();
  return normalizedValue.length > 0 ? normalizedValue : null;
}

function mapBlogPostFormError(field: PropertyKey | undefined): string {
  switch (field) {
    case "title":
      return "missing_title";
    case "slug":
      return "missing_slug";
    case "status":
      return "invalid_status";
    default:
      return "save_failed";
  }
}

export async function updateBlogPostAction(formData: FormData): Promise<void> {
  const blogPostId = normalizeBlogPostId(formData.get("blogPostId"));

  if (blogPostId === null) {
    redirect("/admin/content/blog?error=missing_blog_post");
  }

  const parsed = BlogPostFormSchema.safeParse({
    title: formData.get("title"),
    slug: formData.get("slug"),
    excerpt: formData.get("excerpt"),
    content: formData.get("content"),
    seoTitle: formData.get("seoTitle"),
    seoDescription: formData.get("seoDescription"),
    status: formData.get("status"),
    primaryImageMediaAssetId: formData.get("primaryImageMediaAssetId"),
    currentPrimaryImagePath: formData.get("currentPrimaryImagePath"),
    coverImageMediaAssetId: formData.get("coverImageMediaAssetId"),
    currentCoverImagePath: formData.get("currentCoverImagePath"),
  });

  if (!parsed.success) {
    const code = mapBlogPostFormError(parsed.error.issues[0]?.path[0]);
    redirect(`/admin/content/blog/${blogPostId}?error=${code}`);
  }

  const slug = normalizeBlogPostSlug(parsed.data.slug);

  if (slug.length === 0) {
    redirect(`/admin/content/blog/${blogPostId}?error=invalid_slug`);
  }

  if (parsed.data.status === "published") {
    const publishability = getBlogPostPublishability({
      content: parsed.data.content,
    });

    if (!publishability.ok) {
      redirect(`/admin/content/blog/${blogPostId}?error=${publishability.code}`);
    }
  }

  const primaryImage = parseImageSelection(
    parsed.data.primaryImageMediaAssetId,
    parsed.data.currentPrimaryImagePath
  );
  const coverImage = parseImageSelection(
    parsed.data.coverImageMediaAssetId,
    parsed.data.currentCoverImagePath
  );

  if (!primaryImage.ok || !coverImage.ok) {
    redirect(`/admin/content/blog/${blogPostId}?error=invalid_cover_image`);
  }

  const mediaAssets = await listAdminMediaAssets();

  let primaryImagePath: string | null = null;
  let coverImagePath: string | null = null;

  if (primaryImage.data.kind === "keep_current") {
    primaryImagePath = primaryImage.data.filePath;
  } else if (primaryImage.data.kind === "media_asset") {
    const mediaAsset = mediaAssets.find(
      (asset) => asset.id === primaryImage.data.mediaAssetId
    );

    if (mediaAsset === undefined) {
      redirect(`/admin/content/blog/${blogPostId}?error=cover_media_missing`);
    }

    primaryImagePath = mediaAsset.filePath;
  }

  if (coverImage.data.kind === "keep_current") {
    coverImagePath = coverImage.data.filePath;
  } else if (coverImage.data.kind === "media_asset") {
    const mediaAsset = mediaAssets.find(
      (asset) => asset.id === coverImage.data.mediaAssetId
    );

    if (mediaAsset === undefined) {
      redirect(`/admin/content/blog/${blogPostId}?error=cover_media_missing`);
    }

    coverImagePath = mediaAsset.filePath;
  }

  try {
    const blogPost = await updateAdminBlogPost({
      id: blogPostId,
      title: parsed.data.title,
      slug,
      excerpt: parsed.data.excerpt,
      content: parsed.data.content,
      seoTitle: parsed.data.seoTitle,
      seoDescription: parsed.data.seoDescription,
      primaryImagePath,
      coverImagePath,
      status: parsed.data.status,
    });

    if (blogPost === null) {
      redirect("/admin/content/blog?error=missing_blog_post");
    }
  } catch (error: unknown) {
    if (error instanceof AdminBlogServiceError && error.code === "slug_taken") {
      redirect(`/admin/content/blog/${blogPostId}?error=slug_taken`);
    }

    console.error(error);
    redirect(`/admin/content/blog/${blogPostId}?error=save_failed`);
  }

  redirect(`/admin/content/blog/${blogPostId}?status=updated`);
}
