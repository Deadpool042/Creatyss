"use server";

import { redirect } from "next/navigation";
import { createAdminBlogPost } from "../services";
import { AdminBlogServiceError } from "../types";
import { listAdminMediaAssets } from "@/features/admin/media";
import { normalizeBlogPostSlug } from "@/entities/blog/blog-post-input";
import { BlogPostFormSchema, parseImageSelection } from "../schemas/blog-post-form-schema";

function mapBlogPostFormError(field: PropertyKey | undefined): string {
  switch (field) {
    case "title":
      return "missing_title";
    case "slug":
      return "missing_slug";
    case "status":
      return "invalid_status";
    default:
      return "save_failed";
  }
}

export async function createBlogPostAction(formData: FormData): Promise<void> {
  const parsed = BlogPostFormSchema.safeParse({
    title: formData.get("title"),
    slug: formData.get("slug"),
    excerpt: formData.get("excerpt"),
    content: formData.get("content"),
    seoTitle: formData.get("seoTitle"),
    seoDescription: formData.get("seoDescription"),
    status: formData.get("status"),
    primaryImageMediaAssetId: formData.get("primaryImageMediaAssetId"),
    currentPrimaryImagePath: null,
    coverImageMediaAssetId: formData.get("coverImageMediaAssetId"),
    currentCoverImagePath: null,
  });

  if (!parsed.success) {
    const code = mapBlogPostFormError(parsed.error.issues[0]?.path[0]);
    redirect(`/admin/content/blog/new?error=${code}`);
  }

  const slug = normalizeBlogPostSlug(parsed.data.slug);

  if (slug.length === 0) {
    redirect("/admin/content/blog/new?error=invalid_slug");
  }

  const primaryImage = parseImageSelection(
    parsed.data.primaryImageMediaAssetId,
    parsed.data.currentPrimaryImagePath
  );
  const coverImage = parseImageSelection(
    parsed.data.coverImageMediaAssetId,
    parsed.data.currentCoverImagePath
  );

  if (!primaryImage.ok || !coverImage.ok) {
    redirect("/admin/content/blog/new?error=invalid_cover_image");
  }

  const mediaAssets = await listAdminMediaAssets();

  let primaryImagePath: string | null = null;
  let coverImagePath: string | null = null;

  if (primaryImage.data.kind === "media_asset") {
    const mediaAsset = mediaAssets.find(
      (asset) => asset.id === primaryImage.data.mediaAssetId
    );

    if (mediaAsset === undefined) {
      redirect("/admin/content/blog/new?error=cover_media_missing");
    }

    primaryImagePath = mediaAsset.filePath;
  }

  if (coverImage.data.kind === "media_asset") {
    const mediaAsset = mediaAssets.find(
      (asset) => asset.id === coverImage.data.mediaAssetId
    );

    if (mediaAsset === undefined) {
      redirect("/admin/content/blog/new?error=cover_media_missing");
    }

    coverImagePath = mediaAsset.filePath;
  }

  try {
    const blogPost = await createAdminBlogPost({
      title: parsed.data.title,
      slug,
      excerpt: parsed.data.excerpt,
      content: parsed.data.content,
      seoTitle: parsed.data.seoTitle,
      seoDescription: parsed.data.seoDescription,
      primaryImagePath,
      coverImagePath,
      status: parsed.data.status,
    });

    redirect(`/admin/content/blog/${blogPost.id}?status=created`);
  } catch (error: unknown) {
    if (error instanceof AdminBlogServiceError && error.code === "slug_taken") {
      redirect("/admin/content/blog/new?error=slug_taken");
    }

    console.error(error);
    redirect("/admin/content/blog/new?error=save_failed");
  }
}
