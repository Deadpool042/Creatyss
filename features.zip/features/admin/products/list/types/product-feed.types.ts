import type { AdminProductListCategory, AdminProductListPriceSummary } from "./admin-product-list-item.types";

export type AdminProductsFeedSort =
  | "updated-desc"
  | "updated-asc"
  | "name-asc"
  | "name-desc";

export type AdminProductsFeedStatus =
  | "draft"
  | "active"
  | "inactive"
  | "archived";

export type AdminProductFeedCursor = string;

export type AdminProductFeedItem = {
  id: string;
  slug: string;
  name: string;
  shortDescription: string | null;
  status: AdminProductsFeedStatus;
  isFeatured: boolean;
  productType: "simple" | "variable" | "typed";
  productTypeCode: string | null;
  variantCount: number;
  categoryCount: number;
  primaryCategory: AdminProductListCategory | null;
  primaryImageUrl: string | null;
  primaryImageAlt: string | null;
  amount: string | null;
  compareAtAmount: string | null;
  priceSummary: AdminProductListPriceSummary;
  updatedAt: string;
  stockQuantity: number;
  stockState: "in-stock" | "low-stock" | "out-of-stock";
  diagnostics: {
    missingPrimaryImage: boolean;
    missingPrice: boolean;
  };
};

export type GetAdminProductsFeedPageInput = {
  limit: number;
  cursor: AdminProductFeedCursor | null;
  search: string | null;
  status: readonly AdminProductsFeedStatus[];
  categoryId: string | null;
  featured: boolean | null;
  sort: AdminProductsFeedSort;
};

export type GetAdminProductsFeedPageResult = {
  items: AdminProductFeedItem[];
  nextCursor: AdminProductFeedCursor | null;
  hasMore: boolean;
};
