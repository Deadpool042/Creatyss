import type {
  ProductFilterFeaturedOption,
  ProductFilterImageOption,
  ProductFilterStockOption,
  ProductFilterVariantOption,
  ProductSortOption,
} from "@/features/admin/products/list/types/product-table.types";

export function getStatusLabel(status: "draft" | "active" | "inactive" | "archived"): string {
  switch (status) {
    case "draft":
      return "Brouillon";
    case "active":
      return "Actif";
    case "inactive":
      return "Inactif";
    case "archived":
      return "Archivé";
  }
}

export function getFeaturedLabel(value: ProductFilterFeaturedOption): string {
  switch (value) {
    case "all":
      return "Tous";
    case "featured":
      return "Mis en avant";
    case "not-featured":
      return "Non mis en avant";
  }
}

export function getImageLabel(value: ProductFilterImageOption): string {
  switch (value) {
    case "all":
      return "Toutes";
    case "with-image":
      return "Avec image";
    case "without-image":
      return "Sans image";
  }
}

export function getVariantLabel(value: ProductFilterVariantOption): string {
  switch (value) {
    case "all":
      return "Tous";
    case "simple":
      return "Simples";
    case "variable":
      return "À variantes";
  }
}

export function getStockLabel(value: ProductFilterStockOption): string {
  switch (value) {
    case "all":
      return "Tous";
    case "in-stock":
      return "En stock";
    case "low-stock":
      return "Stock faible";
    case "out-of-stock":
      return "Rupture";
  }
}

export function getSortLabel(value: ProductSortOption): string {
  switch (value) {
    case "updated-desc":
      return "Mise à jour récente";
    case "updated-asc":
      return "Mise à jour ancienne";
    case "name-asc":
      return "Nom A → Z";
    case "name-desc":
      return "Nom Z → A";
  }
}
