import { db } from "@/core/db";
import { mapProductListItem } from "@/features/admin/products/list/mappers/map-product-list-item";
import type { AdminProductListItem } from "@/features/admin/products/list/types";

export async function listAdminProducts(): Promise<readonly AdminProductListItem[]> {
  const products = await db.product.findMany({
    where: {
      archivedAt: null,
    },
    orderBy: [{ updatedAt: "desc" }, { createdAt: "desc" }],
    select: {
      id: true,
      slug: true,
      name: true,
      shortDescription: true,
      status: true,
      isFeatured: true,
      updatedAt: true,
      primaryImage: {
        select: {
          publicUrl: true,
          altText: true,
        },
      },
      productType: {
        select: {
          code: true,
        },
      },
      productCategories: {
        where: {
          archivedAt: null,
          category: {
            archivedAt: null,
          },
        },
        orderBy: [
          { isPrimary: "desc" },
          { sortOrder: "asc" },
          { createdAt: "asc" },
        ],
        take: 1,
        select: {
          category: {
            select: {
              id: true,
              slug: true,
              name: true,
              parent: {
                select: {
                  name: true,
                },
              },
            },
          },
        },
      },
      variants: {
        where: {
          archivedAt: null,
        },
        select: {
          inventoryItems: {
            where: {
              archivedAt: null,
            },
            select: {
              onHandQuantity: true,
              reservedQuantity: true,
            },
          },
          prices: {
            where: {
              archivedAt: null,
            },
            select: {
              amount: true,
              compareAtAmount: true,
            },
          },
        },
      },
      _count: {
        select: {
          variants: {
            where: {
              archivedAt: null,
            },
          },
          productCategories: {
            where: {
              archivedAt: null,
            },
          },
        },
      },
    },
  });

  return products.map(mapProductListItem);
}
