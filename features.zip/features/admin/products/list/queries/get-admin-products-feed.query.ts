import { listAdminProducts } from "./list-admin-products.query";
import type {
  AdminProductFeedItem,
  AdminProductFeedPageResult,
} from "@/features/admin/products/list/types/product-feed.types";

function mapListItemToFeedItem(item: Awaited<ReturnType<typeof listAdminProducts>>[number]): AdminProductFeedItem {
  return {
    id: item.id,
    slug: item.slug,
    name: item.name,
    shortDescription: item.shortDescription,
    status: item.status,
    isFeatured: item.isFeatured,
    productType: item.productType,
    productTypeCode: item.productTypeCode,
    variantCount: item.variantCount,
    categoryCount: item.categoryCount,
    primaryCategory: item.primaryCategory,
    primaryImageUrl: item.primaryImageUrl,
    primaryImageAlt: item.primaryImageAlt,
    amount: item.amount,
    compareAtAmount: item.compareAtAmount,
    priceSummary: item.priceSummary,
    updatedAt: item.updatedAt,
    stockQuantity: item.stockQuantity,
    stockState: item.stockState,
    diagnostics: item.diagnostics,
  };
}

export async function getAdminProductsFeed(): Promise<AdminProductFeedPageResult> {
  const items = await listAdminProducts();

  return {
    items: items.map(mapListItemToFeedItem),
    totalCount: items.length,
    page: 1,
    pageSize: items.length,
    pageCount: 1,
  };
}
