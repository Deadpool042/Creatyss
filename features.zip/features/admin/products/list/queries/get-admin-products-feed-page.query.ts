import { ProductStatus, Prisma } from "@/prisma-generated/client";

import { db } from "@/core/db";
import { mapProductListItem } from "@/features/admin/products/list/mappers/map-product-list-item";
import type {
  AdminProductFeedCursor,
  AdminProductFeedItem,
  AdminProductsFeedSort,
  AdminProductsFeedStatus,
  GetAdminProductsFeedPageInput,
  GetAdminProductsFeedPageResult,
} from "@/features/admin/products/list/types";

type CursorPayload =
  | {
      sort: "updated-desc" | "updated-asc";
      updatedAt: string;
      id: string;
    }
  | {
      sort: "name-asc" | "name-desc";
      name: string;
      id: string;
    };

type ProductListSource = {
  id: string;
  slug: string | null;
  name: string;
  shortDescription: string | null;
  status: ProductStatus;
  isFeatured: boolean;
  updatedAt: Date;
  primaryImage: {
    publicUrl: string | null;
    altText: string | null;
  } | null;
  productType: {
    code: string;
  } | null;
  productCategories: Array<{
    category: {
      id: string;
      slug: string;
      name: string;
      parent: {
        name: string;
      } | null;
    };
  }>;
  variants: Array<{
    inventoryItems: Array<{
      onHandQuantity: number;
      reservedQuantity: number;
    }>;
    prices: Array<{
      amount: { toString(): string };
      compareAtAmount: { toString(): string } | null;
    }>;
  }>;
  _count: {
    variants: number;
    productCategories: number;
  };
};

function decodeCursor(cursor: AdminProductFeedCursor | null): CursorPayload | null {
  if (cursor === null) {
    return null;
  }

  try {
    const parsed = JSON.parse(Buffer.from(cursor, "base64url").toString("utf8")) as CursorPayload;
    return parsed;
  } catch {
    return null;
  }
}

function encodeCursor(payload: CursorPayload): AdminProductFeedCursor {
  return Buffer.from(JSON.stringify(payload), "utf8").toString("base64url");
}

function mapAdminStatusToPrismaStatus(statuses: readonly AdminProductsFeedStatus[]): ProductStatus[] {
  return statuses.map((status) => {
    switch (status) {
      case "draft":
        return ProductStatus.DRAFT;
      case "active":
        return ProductStatus.ACTIVE;
      case "inactive":
        return ProductStatus.INACTIVE;
      case "archived":
        return ProductStatus.ARCHIVED;
    }
  });
}

function clampLimit(limit: number): number {
  if (!Number.isFinite(limit)) {
    return 20;
  }

  const normalized = Math.trunc(limit);

  if (normalized < 1) {
    return 1;
  }

  if (normalized > 50) {
    return 50;
  }

  return normalized;
}

function buildBaseWhere(input: GetAdminProductsFeedPageInput): Prisma.ProductWhereInput {
  const where: Prisma.ProductWhereInput = {
    archivedAt: null,
  };

  if (input.search !== null && input.search.trim().length > 0) {
    const search = input.search.trim();

    where.OR = [
      {
        name: {
          contains: search,
          mode: "insensitive",
        },
      },
      {
        slug: {
          contains: search,
          mode: "insensitive",
        },
      },
      {
        skuRoot: {
          contains: search,
          mode: "insensitive",
        },
      },
      {
        shortDescription: {
          contains: search,
          mode: "insensitive",
        },
      },
    ];
  }

  if (input.status.length > 0) {
    where.status = {
      in: mapAdminStatusToPrismaStatus(input.status),
    };
  }

  if (input.categoryId !== null) {
    where.productCategories = {
      some: {
        archivedAt: null,
        categoryId: input.categoryId,
      },
    };
  }

  if (input.featured !== null) {
    where.isFeatured = input.featured;
  }

  return where;
}

function buildCursorWhere(
  sort: AdminProductsFeedSort,
  cursor: CursorPayload | null,
): Prisma.ProductWhereInput | undefined {
  if (cursor === null) {
    return undefined;
  }

  if ((sort === "updated-desc" || sort === "updated-asc") && "updatedAt" in cursor) {
    const updatedAt = new Date(cursor.updatedAt);

    if (sort === "updated-desc") {
      return {
        OR: [
          {
            updatedAt: {
              lt: updatedAt,
            },
          },
          {
            updatedAt,
            id: {
              lt: cursor.id,
            },
          },
        ],
      };
    }

    return {
      OR: [
        {
          updatedAt: {
            gt: updatedAt,
          },
        },
        {
          updatedAt,
          id: {
            gt: cursor.id,
          },
        },
      ],
    };
  }

  if ((sort === "name-asc" || sort === "name-desc") && "name" in cursor) {
    if (sort === "name-asc") {
      return {
        OR: [
          {
            name: {
              gt: cursor.name,
              mode: "insensitive",
            },
          },
          {
            name: cursor.name,
            id: {
              gt: cursor.id,
            },
          },
        ],
      };
    }

    return {
      OR: [
        {
          name: {
            lt: cursor.name,
            mode: "insensitive",
          },
        },
        {
          name: cursor.name,
          id: {
            lt: cursor.id,
          },
        },
      ],
    };
  }

  return undefined;
}

function buildOrderBy(sort: AdminProductsFeedSort): Prisma.ProductOrderByWithRelationInput[] {
  switch (sort) {
    case "updated-desc":
      return [{ updatedAt: "desc" }, { id: "desc" }];
    case "updated-asc":
      return [{ updatedAt: "asc" }, { id: "asc" }];
    case "name-asc":
      return [{ name: "asc" }, { id: "asc" }];
    case "name-desc":
      return [{ name: "desc" }, { id: "desc" }];
  }
}

function buildNextCursor(
  sort: AdminProductsFeedSort,
  item: ProductListSource,
): AdminProductFeedCursor {
  if (sort === "updated-desc" || sort === "updated-asc") {
    return encodeCursor({
      sort,
      updatedAt: item.updatedAt.toISOString(),
      id: item.id,
    });
  }

  return encodeCursor({
    sort,
    name: item.name,
    id: item.id,
  });
}

export async function getAdminProductsFeedPage(
  input: GetAdminProductsFeedPageInput,
): Promise<GetAdminProductsFeedPageResult> {
  const limit = clampLimit(input.limit);
  const decodedCursor = decodeCursor(input.cursor);
  const baseWhere = buildBaseWhere(input);
  const cursorWhere = buildCursorWhere(input.sort, decodedCursor);

  const where: Prisma.ProductWhereInput =
    cursorWhere === undefined
      ? baseWhere
      : {
          AND: [baseWhere, cursorWhere],
        };

  const products = await db.product.findMany({
    where,
    orderBy: buildOrderBy(input.sort),
    take: limit + 1,
    select: {
      id: true,
      slug: true,
      name: true,
      shortDescription: true,
      status: true,
      isFeatured: true,
      updatedAt: true,
      primaryImage: {
        select: {
          publicUrl: true,
          altText: true,
        },
      },
      productType: {
        select: {
          code: true,
        },
      },
      productCategories: {
        where: {
          archivedAt: null,
          category: {
            archivedAt: null,
          },
        },
        orderBy: [
          { isPrimary: "desc" },
          { sortOrder: "asc" },
          { createdAt: "asc" },
        ],
        take: 1,
        select: {
          category: {
            select: {
              id: true,
              slug: true,
              name: true,
              parent: {
                select: {
                  name: true,
                },
              },
            },
          },
        },
      },
      variants: {
        where: {
          archivedAt: null,
        },
        select: {
          inventoryItems: {
            where: {
              archivedAt: null,
            },
            select: {
              onHandQuantity: true,
              reservedQuantity: true,
            },
          },
          prices: {
            where: {
              archivedAt: null,
            },
            select: {
              amount: true,
              compareAtAmount: true,
            },
          },
        },
      },
      _count: {
        select: {
          variants: {
            where: {
              archivedAt: null,
            },
          },
          productCategories: {
            where: {
              archivedAt: null,
            },
          },
        },
      },
    },
  });

  const hasMore = products.length > limit;
  const pageItems = hasMore ? products.slice(0, limit) : products;

  const items: AdminProductFeedItem[] = pageItems.map((product) => {
    const mapped = mapProductListItem(product);

    return {
      id: mapped.id,
      slug: mapped.slug,
      name: mapped.name,
      shortDescription: mapped.shortDescription,
      status: mapped.status,
      isFeatured: mapped.isFeatured,
      productType: mapped.productType,
      productTypeCode: mapped.productTypeCode,
      variantCount: mapped.variantCount,
      categoryCount: mapped.categoryCount,
      primaryCategory: mapped.primaryCategory,
      primaryImageUrl: mapped.primaryImageUrl,
      primaryImageAlt: mapped.primaryImageAlt,
      amount: mapped.amount,
      compareAtAmount: mapped.compareAtAmount,
      priceSummary: mapped.priceSummary,
      updatedAt: mapped.updatedAt,
      stockQuantity: mapped.stockQuantity,
      stockState: mapped.stockState,
      diagnostics: mapped.diagnostics,
    };
  });

  const nextCursor =
    hasMore && pageItems.length > 0
      ? buildNextCursor(input.sort, pageItems[pageItems.length - 1] as ProductListSource)
      : null;

  return {
    items,
    nextCursor,
    hasMore,
  };
}
