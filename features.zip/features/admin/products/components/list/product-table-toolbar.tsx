"use client";

import Link from "next/link";
import { ChevronDown, Filter, SlidersHorizontal } from "lucide-react";
import { useState, type JSX } from "react";

import { AdminDataTableActiveFilters } from "@/components/admin/tables/admin-data-table-active-filters";
import { AdminDataTableFiltersSheet } from "@/components/admin/tables/admin-data-table-filters-sheet";
import { AdminSearchInput } from "@/components/admin/tables/admin-search-input";
import { Button } from "@/components/ui/button";
import type { ProductTableFiltersState } from "@/features/admin/products/list/hooks/use-product-table-filters";
import type { ProductFilterCategoryOption } from "@/features/admin/products/list/types/product-table.types";
import { cn } from "@/lib/utils";
import { ProductSearchSheet } from "./product-search-sheet";
import { ProductTableFiltersForm } from "./product-table-filters-form";

const MOBILE_STICKY_TOOLBAR_HEIGHT_CLASS_NAME = "h-13 [@media(max-height:480px)]:h-11";

type ProductListView = "active" | "trash";

type ProductTableToolbarProps = {
  categoryOptions: ProductFilterCategoryOption[];
  state: ProductTableFiltersState;
  mode: "desktop" | "mobile";
  view: ProductListView;
  selectedCount?: number;
  onClearSelection?: () => void;
  bulkMessage?: string | null;
  bulkError?: string | null;
  isBulkPending?: boolean;
  onBulkSetDraft?: () => void;
  onBulkSetActive?: () => void;
  onBulkSetInactive?: () => void;
  onBulkSetFeatured?: () => void;
  onBulkUnsetFeatured?: () => void;
  onBulkArchive?: () => void;
  onBulkRestore?: () => void;
};

function ResultsCount({
  filteredCount,
  className,
}: {
  filteredCount: number;
  className?: string;
}): JSX.Element {
  return (
    <span
      className={cn(
        "inline-flex items-center text-[10px] font-medium italic text-muted-foreground sm:text-[11px]",
        className
      )}
    >
      <span className="[@media(max-height:480px)]:hidden">
        {filteredCount} résultat{filteredCount !== 1 ? "s" : ""}
      </span>
      <span className="hidden [@media(max-height:480px)]:inline">{filteredCount} res.</span>
    </span>
  );
}

function BulkActionButton({
  children,
  onClick,
  disabled,
}: {
  children: string;
  onClick: (() => void) | undefined;
  disabled?: boolean;
}): JSX.Element {
  return (
    <Button
      type="button"
      variant="outline"
      size="sm"
      onClick={onClick}
      disabled={disabled}
      className="h-8 rounded-full px-3 text-xs shadow-none"
    >
      {children}
    </Button>
  );
}

export function ProductTableToolbar({
  categoryOptions,
  state,
  mode,
  view,
  selectedCount = 0,
  onClearSelection,
  bulkMessage = null,
  bulkError = null,
  isBulkPending = false,
  onBulkSetDraft,
  onBulkSetActive,
  onBulkSetInactive,
  onBulkSetFeatured,
  onBulkUnsetFeatured,
  onBulkArchive,
  onBulkRestore,
}: ProductTableToolbarProps): JSX.Element {
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);

  const activeFiltersCount = state.activeFilters.length;
  const hasActiveFilters = activeFiltersCount > 0;
  const hasSelection = selectedCount > 0;

  const mobileFiltersLabel = hasActiveFilters ? `Filtres · ${activeFiltersCount}` : "Filtres";
  const mobileFiltersDescription = hasActiveFilters
    ? `${activeFiltersCount} filtre${activeFiltersCount > 1 ? "s" : ""} actif${activeFiltersCount > 1 ? "s" : ""}.`
    : "Affiner la liste.";

  if (mode === "desktop") {
    return (
      <div className="space-y-1.5">
        <div className="flex items-center gap-2">
          <Button
            asChild
            type="button"
            variant={view === "active" ? "default" : "outline"}
            size="sm"
            className="h-8 rounded-full px-3 text-xs"
          >
            <Link href="/admin/products">Actifs</Link>
          </Button>

          <Button
            asChild
            type="button"
            variant={view === "trash" ? "default" : "outline"}
            size="sm"
            className="h-8 rounded-full px-3 text-xs"
          >
            <Link href="/admin/products?view=trash">Corbeille</Link>
          </Button>
        </div>

        {bulkMessage ? (
          <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-800 shadow-card">
            {bulkMessage}
          </div>
        ) : null}

        {bulkError ? (
          <div className="rounded-xl border border-destructive/20 bg-destructive/5 px-3 py-2 text-sm text-destructive shadow-card">
            {bulkError}
          </div>
        ) : null}

        {hasSelection ? (
          <div className="rounded-xl border border-surface-border-strong bg-interactive-selected px-3 py-3 shadow-card">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <p className="text-sm font-medium text-foreground">
                {selectedCount} produit{selectedCount > 1 ? "s" : ""} sélectionné
                {selectedCount > 1 ? "s" : ""}
              </p>

              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={onClearSelection}
                className="h-8 rounded-full px-3 text-xs"
                disabled={isBulkPending}
              >
                Effacer la sélection
              </Button>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {view === "active" ? (
                <>
                  <BulkActionButton onClick={onBulkSetDraft} disabled={isBulkPending}>
                    Mettre en brouillon
                  </BulkActionButton>

                  <BulkActionButton onClick={onBulkSetActive} disabled={isBulkPending}>
                    Activer
                  </BulkActionButton>

                  <BulkActionButton onClick={onBulkSetInactive} disabled={isBulkPending}>
                    Désactiver
                  </BulkActionButton>

                  <BulkActionButton onClick={onBulkSetFeatured} disabled={isBulkPending}>
                    Mettre en avant
                  </BulkActionButton>

                  <BulkActionButton onClick={onBulkUnsetFeatured} disabled={isBulkPending}>
                    Retirer la mise en avant
                  </BulkActionButton>

                  <BulkActionButton onClick={onBulkArchive} disabled={isBulkPending}>
                    Mettre à la corbeille
                  </BulkActionButton>
                </>
              ) : (
                <BulkActionButton onClick={onBulkRestore} disabled={isBulkPending}>
                  Restaurer
                </BulkActionButton>
              )}
            </div>
          </div>
        ) : null}

        <div className="rounded-xl border border-surface-border bg-card p-3 lg:p-4 shadow-card">
          <div className="space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="min-w-0 max-w-120 flex-1 xl:max-w-136 2xl:max-w-152">
                <AdminSearchInput
                  value={state.search}
                  onChange={state.handleSearchChange}
                  placeholder={
                    view === "trash" ? "Rechercher un produit archivé…" : "Rechercher un produit…"
                  }
                  className="relative w-full"
                />
              </div>

              <div className="flex shrink-0 items-center gap-2">
                <ResultsCount
                  filteredCount={state.filteredCount}
                  className="whitespace-nowrap rounded-full border border-surface-border bg-surface-panel-soft px-2.5 py-1"
                />

                <Button
                  variant="outline"
                  size="sm"
                  type="button"
                  onClick={() => state.setShowAdvancedFilters(!state.showAdvancedFilters)}
                  className={cn(
                    "inline-flex h-9 items-center gap-2 rounded-full px-3",
                    hasActiveFilters &&
                      "border-surface-border-strong bg-interactive-selected text-foreground hover:bg-interactive-selected"
                  )}
                  aria-expanded={state.showAdvancedFilters}
                >
                  <SlidersHorizontal className="h-4 w-4" />
                  {hasActiveFilters ? `Filtres · ${activeFiltersCount}` : "Filtres"}
                  <ChevronDown
                    className={cn(
                      "h-3.5 w-3.5 text-muted-foreground transition-transform duration-200",
                      state.showAdvancedFilters && "rotate-180"
                    )}
                  />
                </Button>
              </div>
            </div>

            <div className="min-w-0">
              <ProductTableFiltersForm
                categoryOptions={categoryOptions}
                state={state}
                mode="primary"
              />
            </div>
          </div>

          {state.showAdvancedFilters ? (
            <div className="mt-3 border-t border-surface-border pt-3">
              <div className="grid gap-2 xl:grid-cols-2 2xl:grid-cols-4">
                <ProductTableFiltersForm
                  categoryOptions={categoryOptions}
                  state={state}
                  mode="secondary"
                />
              </div>
            </div>
          ) : null}
        </div>

        {hasActiveFilters ? (
          <AdminDataTableActiveFilters items={state.activeFilters} onClearAll={state.reset} />
        ) : null}
      </div>
    );
  }

  return (
    <>
      <div className={cn("lg:hidden", MOBILE_STICKY_TOOLBAR_HEIGHT_CLASS_NAME)}>
        <div className="-mx-3 site-header-blur flex h-full items-center border-b border-shell-border px-3 shadow-card [@media(max-height:480px)]:-mx-2.5 [@media(max-height:480px)]:px-2.5">
          <div className="flex w-full items-center gap-2 [@media(max-height:480px)]:gap-1.5">
            <div className="flex min-w-0 flex-1 items-center gap-2 [@media(max-height:480px)]:gap-1.5">
              <ProductSearchSheet
                open={mobileSearchOpen}
                onOpenChange={setMobileSearchOpen}
                value={state.search}
                onChange={state.handleSearchChange}
                triggerClassName="shrink-0"
              />

              <Button
                variant="outline"
                size="sm"
                type="button"
                onClick={() => state.setMobileFiltersOpen(true)}
                className={cn(
                  "inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full px-3 text-xs [@media(max-height:480px)]:h-8 [@media(max-height:480px)]:gap-1 [@media(max-height:480px)]:px-2.5 [@media(max-height:480px)]:text-[11px]",
                  hasActiveFilters &&
                    "border-surface-border-strong bg-interactive-selected text-foreground hover:bg-interactive-selected"
                )}
              >
                <Filter className="h-4 w-4" />
                <span>{mobileFiltersLabel}</span>
              </Button>
            </div>

            <ResultsCount
              filteredCount={state.filteredCount}
              className="shrink-0 whitespace-nowrap rounded-full border border-surface-border bg-surface-panel-soft px-2.5 py-1 [@media(max-height:480px)]:px-2"
            />
          </div>
        </div>
      </div>

      <AdminDataTableFiltersSheet
        open={state.mobileFiltersOpen}
        onOpenChange={state.setMobileFiltersOpen}
        title={hasActiveFilters ? `Filtres produits · ${activeFiltersCount}` : "Filtres produits"}
        description={mobileFiltersDescription}
        footer={
          <div className="flex items-center justify-between gap-3">
            <Button
              variant="ghost"
              type="button"
              onClick={state.reset}
              className="h-9 rounded-full px-3 text-muted-foreground [@media(max-height:480px)]:h-8"
              disabled={!hasActiveFilters}
            >
              Réinitialiser
            </Button>

            <Button
              type="button"
              onClick={() => state.setMobileFiltersOpen(false)}
              className="h-9 rounded-full px-4 [@media(max-height:480px)]:h-8"
            >
              Appliquer
            </Button>
          </div>
        }
      >
        <div className="space-y-3.5 [@media(max-height:480px)]:space-y-3">
          {hasActiveFilters ? (
            <div className="rounded-xl border border-surface-border bg-surface-panel-soft p-3">
              <div className="mb-2 flex items-center justify-between gap-3">
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                  Filtres actifs
                </p>

                <span className="rounded-full border border-surface-border bg-card px-2 py-0.5 text-[11px] font-medium text-muted-foreground">
                  {activeFiltersCount}
                </span>
              </div>

              <AdminDataTableActiveFilters items={state.activeFilters} onClearAll={state.reset} />
            </div>
          ) : null}

          <ProductTableFiltersForm categoryOptions={categoryOptions} state={state} mode="mobile" />
        </div>
      </AdminDataTableFiltersSheet>
    </>
  );
}
