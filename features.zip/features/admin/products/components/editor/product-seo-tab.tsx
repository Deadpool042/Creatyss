"use client";

import { useActionState, useMemo, useState, type JSX } from "react";

import { AdminFormFooter } from "@/components/admin/forms/admin-form-footer";
import { AdminFormMessage } from "@/components/admin/forms/admin-form-message";
import {
  SeoDefaultValues,
  SeoEditorBlock,
  SeoMetaFields,
  SeoPreviewInspector,
  SeoPreviewSheet,
  SeoSocialSummaryCard,
  SeoVisibilityFields,
} from "@/components/admin/seo";
import { SectionIntro } from "@/components/shared/section-intro";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import type { SeoIndexingMode } from "@/entities/seo";
import {
  productSeoFormInitialState,
  type AdminProductEditorData,
  type ProductSeoFormAction,
} from "@/features/admin/products/editor/types";

type ProductSeoTabProps = {
  action: ProductSeoFormAction;
  product: AdminProductEditorData;
};

type ProductSeoTabInnerProps = {
  action: ProductSeoFormAction;
  product: AdminProductEditorData;
  onReset: () => void;
};

const TABS = [
  { id: "principal", label: "Principal" },
  { id: "visibilite", label: "Visibilité" },
  { id: "social", label: "Partage social" },
] as const;

type SeoTabId = (typeof TABS)[number]["id"];
type SeoTabDefinition = (typeof TABS)[number];

const SEO_TAB_PANEL_COPY: Record<SeoTabId, { title: string; description: string }> = {
  principal: {
    title: "Référencement principal",
    description: "Renseignez le titre, la description et l’URL canonique utilisés par défaut.",
  },
  visibilite: {
    title: "Visibilité",
    description: "Contrôlez l’indexation du produit et sa présence dans le sitemap.",
  },
  social: {
    title: "Partage social",
    description: "Préparez l’aperçu Open Graph utilisé par les réseaux et les messageries.",
  },
};

type ProductSeoFormState = typeof productSeoFormInitialState;
type OpenGraphImageOption = {
  id: string;
  label: string;
  imageUrl: string | null;
};

type SeoDesktopTabsColumnProps = {
  activeTab: SeoTabId;
  onTabChange: (tab: SeoTabId) => void;
};

type SeoDesktopContentColumnProps = {
  activeTab: SeoTabId;
  panelTitle: string;
  panelDescription: string;
  state: ProductSeoFormState;
  metaTitle: string;
  metaDescription: string;
  canonicalPath: string;
  indexingMode: SeoIndexingMode;
  sitemapIncluded: boolean;
  openGraphTitle: string;
  openGraphDescription: string;
  openGraphImageId: string;
  openGraphImageOptions: OpenGraphImageOption[];
  resolvedOpenGraphTitle: string;
  resolvedOpenGraphDescription: string;
  resolvedOpenGraphImageUrl: string | null;
  product: AdminProductEditorData;
  onMetaTitleChange: (value: string) => void;
  onMetaDescriptionChange: (value: string) => void;
  onCanonicalPathChange: (value: string) => void;
  onIndexingModeChange: (value: SeoIndexingMode) => void;
  onSitemapIncludedChange: (value: boolean) => void;
  onOpenGraphTitleChange: (value: string) => void;
  onOpenGraphDescriptionChange: (value: string) => void;
  onOpenGraphImageIdChange: (value: string) => void;
};

type SeoDesktopPreviewColumnProps = {
  publicPath: string;
  title: string;
  description: string;
  openGraphTitle: string;
  openGraphDescription: string;
  openGraphImageUrl: string | null;
  indexingMode: SeoIndexingMode;
  sitemapIncluded: boolean;
};

function SeoDesktopTabsColumn({ activeTab, onTabChange }: SeoDesktopTabsColumnProps): JSX.Element {
  return (
    <nav className="hidden xl:block">
      <div
        role="tablist"
        aria-label="Sections SEO"
        aria-orientation="vertical"
        className="rounded-xl border border-surface-border bg-card p-1.5 shadow-card"
      >
        {TABS.map((tab: SeoTabDefinition) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => onTabChange(tab.id)}
            role="tab"
            aria-selected={activeTab === tab.id}
            aria-controls="seo-tab-panel"
            tabIndex={activeTab === tab.id ? 0 : -1}
            className={cn(
              "w-full rounded-lg border border-transparent px-3 py-2 text-left text-sm transition-colors focus-visible:outline-none focus-visible:border-focus-ring focus-visible:ring-3 focus-visible:ring-focus-ring/50",
              activeTab === tab.id
                ? "bg-interactive-selected font-medium text-foreground"
                : "font-normal text-muted-foreground hover:bg-interactive-hover hover:text-foreground"
            )}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </nav>
  );
}

function SeoDesktopContentColumn({
  activeTab,
  panelTitle,
  panelDescription,
  state,
  metaTitle,
  metaDescription,
  canonicalPath,
  indexingMode,
  sitemapIncluded,
  openGraphTitle,
  openGraphDescription,
  openGraphImageId,
  openGraphImageOptions,
  resolvedOpenGraphTitle,
  resolvedOpenGraphDescription,
  resolvedOpenGraphImageUrl,
  product,
  onMetaTitleChange,
  onMetaDescriptionChange,
  onCanonicalPathChange,
  onIndexingModeChange,
  onSitemapIncludedChange,
  onOpenGraphTitleChange,
  onOpenGraphDescriptionChange,
  onOpenGraphImageIdChange,
}: SeoDesktopContentColumnProps): JSX.Element {
  return (
    <div
      id="seo-tab-panel"
      role="tabpanel"
      aria-label={panelTitle}
      className="min-h-0 min-w-0 xl:h-full xl:overflow-y-auto overscroll-contain xl:pr-2 xl:pb-14"
    >
      <div className="space-y-4 md:space-y-5 [@media(max-height:480px)]:space-y-3">
        <AdminFormMessage tone="error" message={state.status === "error" ? state.message : null} />
        <AdminFormMessage
          tone="success"
          message={state.status === "success" ? state.message : null}
        />

        <SectionIntro
          className="hidden xl:grid xl:gap-1"
          title={panelTitle}
          description={panelDescription}
          titleAs="h3"
        />

        {activeTab === "principal" && (
          <div className="space-y-4 md:space-y-5">
            <SeoMetaFields
              metaTitle={metaTitle}
              metaDescription={metaDescription}
              canonicalPath={canonicalPath}
              onMetaTitleChange={onMetaTitleChange}
              onMetaDescriptionChange={onMetaDescriptionChange}
              onCanonicalPathChange={onCanonicalPathChange}
              {...(state.fieldErrors.seoTitle
                ? { metaTitleError: state.fieldErrors.seoTitle }
                : {})}
              {...(state.fieldErrors.seoDescription
                ? { metaDescriptionError: state.fieldErrors.seoDescription }
                : {})}
              {...(state.fieldErrors.seoCanonicalPath
                ? { canonicalPathError: state.fieldErrors.seoCanonicalPath }
                : {})}
            />

            <SeoEditorBlock
              title="Valeurs par défaut"
              description="Référence utilisée quand aucun contenu spécifique n’est renseigné."
            >
              <SeoDefaultValues
                items={[
                  { label: "Titre", value: product.seo.fallbackTitle },
                  { label: "Description", value: product.seo.fallbackDescription },
                  { label: "URL canonique", value: product.seo.fallbackCanonicalPath },
                ]}
              />
            </SeoEditorBlock>
          </div>
        )}
        {activeTab === "visibilite" && (
          <SeoVisibilityFields
            indexingMode={indexingMode}
            sitemapIncluded={sitemapIncluded}
            onIndexingModeChange={onIndexingModeChange}
            onSitemapIncludedChange={onSitemapIncludedChange}
            {...(state.fieldErrors.seoIndexingMode
              ? { indexingModeError: state.fieldErrors.seoIndexingMode }
              : {})}
            {...(state.fieldErrors.seoSitemapIncluded
              ? { sitemapIncludedError: state.fieldErrors.seoSitemapIncluded }
              : {})}
          />
        )}

        {activeTab === "social" && (
          <SeoSocialSummaryCard
            resolvedTitle={resolvedOpenGraphTitle}
            resolvedDescription={resolvedOpenGraphDescription}
            imagePreviewUrl={resolvedOpenGraphImageUrl}
            openGraphTitle={openGraphTitle}
            openGraphDescription={openGraphDescription}
            openGraphImageId={openGraphImageId}
            imageOptions={openGraphImageOptions}
            fallbackOpenGraphTitle={product.seo.fallbackOpenGraphTitle}
            fallbackOpenGraphDescription={product.seo.fallbackOpenGraphDescription}
            fallbackOpenGraphImageUrl={product.seo.fallbackOpenGraphImageUrl}
            onOpenGraphTitleChange={onOpenGraphTitleChange}
            onOpenGraphDescriptionChange={onOpenGraphDescriptionChange}
            onImageIdChange={onOpenGraphImageIdChange}
            {...(state.fieldErrors.seoOpenGraphTitle
              ? { openGraphTitleError: state.fieldErrors.seoOpenGraphTitle }
              : {})}
            {...(state.fieldErrors.seoOpenGraphDescription
              ? { openGraphDescriptionError: state.fieldErrors.seoOpenGraphDescription }
              : {})}
            {...(state.fieldErrors.seoOpenGraphImageId
              ? { imageIdError: state.fieldErrors.seoOpenGraphImageId }
              : {})}
          />
        )}
      </div>
    </div>
  );
}

function SeoDesktopPreviewColumn({
  publicPath,
  title,
  description,
  openGraphTitle,
  openGraphDescription,
  openGraphImageUrl,
  indexingMode,
  sitemapIncluded,
}: SeoDesktopPreviewColumnProps): JSX.Element {
  return (
    <aside className="hidden min-h-0 xl:block xl:h-full xl:overflow-y-auto overscroll-contain xl:pl-2 xl:pb-14 2xl:pl-4">
      <SeoPreviewInspector
        publicPath={publicPath}
        title={title}
        description={description}
        openGraphTitle={openGraphTitle}
        openGraphDescription={openGraphDescription}
        openGraphImageUrl={openGraphImageUrl}
        indexingMode={indexingMode}
        sitemapIncluded={sitemapIncluded}
      />
    </aside>
  );
}

function ProductSeoTabInner({ action, product, onReset }: ProductSeoTabInnerProps): JSX.Element {
  const [state, formAction, pending] = useActionState(action, productSeoFormInitialState);
  const [activeTab, setActiveTab] = useState<SeoTabId>("principal");

  const [metaTitle, setMetaTitle] = useState(product.seo.title);
  const [metaDescription, setMetaDescription] = useState(product.seo.description);
  const [canonicalPath, setCanonicalPath] = useState(product.seo.canonicalPath ?? "");
  const [indexingMode, setIndexingMode] = useState<SeoIndexingMode>(product.seo.indexingMode);
  const [sitemapIncluded, setSitemapIncluded] = useState(product.seo.sitemapIncluded);
  const [openGraphTitle, setOpenGraphTitle] = useState(product.seo.openGraphTitle);
  const [openGraphDescription, setOpenGraphDescription] = useState(
    product.seo.openGraphDescription
  );
  const [openGraphImageId, setOpenGraphImageId] = useState(product.seo.openGraphImageId ?? "");

  const openGraphImageOptions = useMemo<OpenGraphImageOption[]>(
    () =>
      product.images
        .filter((image) => image.url.trim().length > 0)
        .map((image, index) => ({
          id: image.id,
          label:
            image.alt.trim().length > 0
              ? image.alt
              : image.isPrimary
                ? "Image principale"
                : `Image ${index + 1}`,
          imageUrl: image.url,
        })),
    [product.images]
  );

  const selectedOpenGraphImage = openGraphImageOptions.find(
    (image) => image.id === openGraphImageId
  );

  const resolvedPreviewTitle =
    metaTitle.trim().length > 0 ? metaTitle.trim() : product.seo.fallbackTitle;
  const resolvedPreviewDescription =
    metaDescription.trim().length > 0 ? metaDescription.trim() : product.seo.fallbackDescription;
  const resolvedPreviewPath =
    canonicalPath.trim().length > 0 ? canonicalPath.trim() : product.seo.fallbackCanonicalPath;

  const resolvedOpenGraphTitle =
    openGraphTitle.trim().length > 0 ? openGraphTitle.trim() : product.seo.fallbackOpenGraphTitle;

  const resolvedOpenGraphDescription =
    openGraphDescription.trim().length > 0
      ? openGraphDescription.trim()
      : product.seo.fallbackOpenGraphDescription;

  const resolvedOpenGraphImageUrl =
    selectedOpenGraphImage?.imageUrl ?? product.seo.fallbackOpenGraphImageUrl;

  const activeTabPanelCopy = SEO_TAB_PANEL_COPY[activeTab];

  return (
    <form action={formAction} className="relative flex min-h-0 flex-1 flex-col overflow-hidden">
      <input type="hidden" name="id" value={product.id} />
      <input type="hidden" name="seoTitle" value={metaTitle} />
      <input type="hidden" name="seoDescription" value={metaDescription} />
      <input type="hidden" name="seoIndexingMode" value={indexingMode} />
      <input type="hidden" name="seoSitemapIncluded" value={sitemapIncluded ? "true" : "false"} />
      <input type="hidden" name="seoCanonicalPath" value={canonicalPath} />
      <input type="hidden" name="seoOpenGraphTitle" value={openGraphTitle} />
      <input type="hidden" name="seoOpenGraphDescription" value={openGraphDescription} />
      <input type="hidden" name="seoOpenGraphImageId" value={openGraphImageId} />

      <div className="min-h-0 flex-1 overflow-y-auto pt-28.25 pb-[calc(7rem+env(safe-area-inset-bottom))] sm:pt-29.25 md:pt-30.25 [@media(max-height:480px)]:pt-25.25 [@media(max-height:480px)]:pb-[calc(5.5rem+env(safe-area-inset-bottom))] lg:pt-17.25 lg:pb-14 xl:flex xl:flex-col xl:pb-0">
        <div className="min-h-0 w-full space-y-5 px-4 pt-4 pb-4 md:space-y-6 md:px-6 md:pt-6 md:pb-6 lg:mx-auto lg:max-w-7xl lg:px-4 xl:flex xl:flex-1 xl:flex-col xl:overflow-hidden xl:px-4 xl:pb-0 2xl:px-0 [@media(max-height:480px)]:space-y-4 [@media(max-height:480px)]:pt-3 [@media(max-height:480px)]:pb-3">
          <div className="flex items-center gap-3 xl:hidden">
            <div className="min-w-0 flex-1">
              <h2 className="text-base font-semibold tracking-tight text-foreground">SEO</h2>
              <p className="text-sm text-muted-foreground">
                Référencement, visibilité et partage social.
              </p>
            </div>

            <div className="ml-auto">
              <SeoPreviewSheet
                publicPath={resolvedPreviewPath}
                title={resolvedPreviewTitle}
                description={resolvedPreviewDescription}
                openGraphTitle={resolvedOpenGraphTitle}
                openGraphDescription={resolvedOpenGraphDescription}
                openGraphImageUrl={resolvedOpenGraphImageUrl}
              />
            </div>
          </div>

          <div className="xl:hidden">
            <div
              role="tablist"
              aria-label="Sections SEO"
              aria-orientation="horizontal"
              className="flex gap-1 rounded-xl border border-surface-border bg-card p-1 shadow-card"
            >
              {TABS.map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  role="tab"
                  aria-selected={activeTab === tab.id}
                  aria-controls="seo-tab-panel"
                  tabIndex={activeTab === tab.id ? 0 : -1}
                  className={cn(
                    "flex-1 rounded-lg border border-transparent px-3 py-1.5 text-xs font-medium transition-colors focus-visible:outline-none focus-visible:border-focus-ring focus-visible:ring-3 focus-visible:ring-focus-ring/50",
                    activeTab === tab.id
                      ? "bg-interactive-selected text-foreground"
                      : "text-muted-foreground hover:bg-interactive-hover hover:text-foreground"
                  )}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid min-h-0 gap-6 xl:h-full xl:flex-1 xl:grid-cols-[160px_minmax(0,1fr)_20rem] xl:items-start xl:overflow-hidden 2xl:grid-cols-[180px_minmax(0,1fr)_22rem] pb-4">
            <SeoDesktopTabsColumn activeTab={activeTab} onTabChange={setActiveTab} />

            <SeoDesktopContentColumn
              activeTab={activeTab}
              panelTitle={activeTabPanelCopy.title}
              panelDescription={activeTabPanelCopy.description}
              state={state}
              metaTitle={metaTitle}
              metaDescription={metaDescription}
              canonicalPath={canonicalPath}
              indexingMode={indexingMode}
              sitemapIncluded={sitemapIncluded}
              openGraphTitle={openGraphTitle}
              openGraphDescription={openGraphDescription}
              openGraphImageId={openGraphImageId}
              openGraphImageOptions={openGraphImageOptions}
              resolvedOpenGraphTitle={resolvedOpenGraphTitle}
              resolvedOpenGraphDescription={resolvedOpenGraphDescription}
              resolvedOpenGraphImageUrl={resolvedOpenGraphImageUrl}
              product={product}
              onMetaTitleChange={setMetaTitle}
              onMetaDescriptionChange={setMetaDescription}
              onCanonicalPathChange={setCanonicalPath}
              onIndexingModeChange={setIndexingMode}
              onSitemapIncludedChange={setSitemapIncluded}
              onOpenGraphTitleChange={setOpenGraphTitle}
              onOpenGraphDescriptionChange={setOpenGraphDescription}
              onOpenGraphImageIdChange={setOpenGraphImageId}
            />

            <SeoDesktopPreviewColumn
              publicPath={resolvedPreviewPath}
              title={resolvedPreviewTitle}
              description={resolvedPreviewDescription}
              openGraphTitle={resolvedOpenGraphTitle}
              openGraphDescription={resolvedOpenGraphDescription}
              openGraphImageUrl={resolvedOpenGraphImageUrl}
              indexingMode={indexingMode}
              sitemapIncluded={sitemapIncluded}
            />
          </div>
        </div>
      </div>

      <AdminFormFooter
        actionsClassName="w-full justify-between gap-2 sm:w-auto sm:justify-end"
        className={[
          "bottom-[calc(3.5rem+env(safe-area-inset-bottom))]",
          "[@media(max-height:480px)]:bottom-[calc(2.75rem+env(safe-area-inset-bottom))]",
          "lg:bottom-0",
        ].join(" ")}
        overlay
      >
        <Button
          variant="ghost"
          type="button"
          size="xs"
          className="h-8 rounded-full px-4 text-muted-foreground hover:text-foreground lg:h-9"
          onClick={onReset}
        >
          Réinitialiser
        </Button>

        <Button
          type="submit"
          variant="outline"
          size="xs"
          className="h-8 w-fit rounded-full px-4 sm:flex-none lg:h-9"
          disabled={pending}
        >
          {pending ? "Mise à jour…" : "Enregistrer"}
        </Button>
      </AdminFormFooter>
    </form>
  );
}

export function ProductSeoTab({ action, product }: ProductSeoTabProps): JSX.Element {
  const [formInstanceKey, setFormInstanceKey] = useState(0);

  return (
    <ProductSeoTabInner
      key={formInstanceKey}
      action={action}
      product={product}
      onReset={() => setFormInstanceKey((current) => current + 1)}
    />
  );
}
