"use client";

import { useState, type JSX } from "react";
import Image from "next/image";
import { BadgeCheck, Pencil, Star, Tag, Trash2 } from "lucide-react";

import { hasRealImage } from "@/core/media";
import { ConfirmDestructiveDialog, PlaceholderImage } from "@/components/shared";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ProductStatusBadge } from "@/features/admin/products/components/shared";
import type { AdminProductVariantListItem } from "@/features/admin/products/editor/types/product-variants.types";

type ProductVariantItemProps = {
  variant: AdminProductVariantListItem;
  variantCount: number;
  onEdit?: (variantId: string) => void;
  onSetDefault?: (variantId: string) => Promise<{ status: "success" | "error"; message: string }>;
  onDelete?: (variantId: string) => Promise<{ status: "success" | "error"; message: string }>;
};

function formatPrice(amount: string | null): string {
  if (!amount) {
    return "—";
  }

  const parsed = Number.parseFloat(amount);

  if (!Number.isFinite(parsed)) {
    return amount;
  }

  return `${parsed.toFixed(2)} €`;
}

export function ProductVariantItem({
  variant,
  variantCount,
  onEdit,
  onSetDefault,
  onDelete,
}: ProductVariantItemProps): JSX.Element {
  const [isSettingDefault, setIsSettingDefault] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);

  const imageAlt = (variant.primaryImageAlt ?? variant.name) || variant.sku;
  const displayName = variant.name.trim().length > 0 ? variant.name : "Variante sans nom";
  const canDelete = variantCount > 1;
  const canSetDefault = !variant.isDefault;

  async function handleSetDefault(): Promise<void> {
    if (!onSetDefault || !canSetDefault) {
      return;
    }

    setIsSettingDefault(true);
    await onSetDefault(variant.id);
    setIsSettingDefault(false);
  }

  async function handleDelete(): Promise<boolean> {
    if (!onDelete || !canDelete) {
      return false;
    }

    setIsDeleting(true);
    const result = await onDelete(variant.id);
    setIsDeleting(false);

    return result.status === "success";
  }

  return (
    <Card className="rounded-2xl border-border/60">
      <CardContent className="space-y-4 p-4">
        <div className="flex items-start gap-3">
          <div className="relative h-16 w-16 shrink-0 overflow-hidden rounded-xl border bg-muted sm:h-18 sm:w-18">
            {hasRealImage(variant.primaryImageUrl) ? (
              <Image
                src={variant.primaryImageUrl!}
                alt={imageAlt}
                width={112}
                height={112}
                className="h-full w-full object-cover"
              />
            ) : (
              <PlaceholderImage alt={imageAlt} className="bg-muted" imageClassName="opacity-15" />
            )}
          </div>

          <div className="min-w-0 flex-1 space-y-2">
            <div className="space-y-1">
              <h3 className="truncate text-sm font-semibold sm:text-base">{displayName}</h3>

              <div className="flex flex-wrap items-center gap-2">
                <ProductStatusBadge status={variant.status} />

                {variant.isDefault ? (
                  <span className="inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] text-muted-foreground">
                    <BadgeCheck className="h-3.5 w-3.5" />
                    Par défaut
                  </span>
                ) : null}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1">
                <Tag className="h-3.5 w-3.5" />
                SKU : {variant.sku}
              </span>

              {variant.slug ? <span>Slug : {variant.slug}</span> : null}
              <span>Ordre : {variant.sortOrder}</span>
            </div>
          </div>
        </div>

        <div className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-xl border border-border/60 px-3 py-2.5">
            <p className="text-[11px] uppercase tracking-wide text-muted-foreground">Prix</p>
            <p className="mt-1 text-sm font-medium tabular-nums sm:text-base">
              {formatPrice(variant.amount)}
            </p>
          </div>

          <div className="rounded-xl border border-border/60 px-3 py-2.5">
            <p className="text-[11px] uppercase tracking-wide text-muted-foreground">
              Prix avant réduction
            </p>
            <p className="mt-1 text-sm font-medium tabular-nums sm:text-base">
              {formatPrice(variant.compareAtAmount)}
            </p>
          </div>
        </div>

        <div className="grid gap-2 sm:grid-cols-3 sm:justify-end">
          <Button
            variant="outline"
            size="sm"
            type="button"
            onClick={() => onEdit?.(variant.id)}
            disabled={!onEdit || isSettingDefault || isDeleting}
            className="w-full"
          >
            <Pencil className="mr-2 h-4 w-4" />
            Modifier
          </Button>

          <Button
            variant="outline"
            size="sm"
            type="button"
            onClick={() => void handleSetDefault()}
            disabled={!onSetDefault || !canSetDefault || isSettingDefault || isDeleting}
            className="w-full"
          >
            <Star className="mr-2 h-4 w-4" />
            {variant.isDefault ? "Par défaut" : isSettingDefault ? "Application…" : "Définir"}
          </Button>

          <ConfirmDestructiveDialog
            trigger={
              <Button
                variant="outline"
                size="sm"
                type="button"
                disabled={!onDelete || !canDelete || isSettingDefault || isDeleting}
                className="w-full text-destructive"
              >
                <Trash2 className="mr-2 h-4 w-4" />
                {isDeleting ? "Suppression…" : "Supprimer"}
              </Button>
            }
            title="Supprimer cette variante ?"
            description={`La variante "${displayName}" va être supprimée définitivement. Cette action est irréversible.`}
            pending={isDeleting}
            onConfirm={handleDelete}
          />
        </div>

        {!canDelete ? (
          <p className="text-xs text-muted-foreground">
            Le produit doit conserver au moins une variante.
          </p>
        ) : null}
      </CardContent>
    </Card>
  );
}
