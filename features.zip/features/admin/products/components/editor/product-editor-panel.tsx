"use client";

import { useEffect, useState, type JSX } from "react";

import { useAdminPageTitle } from "@/components/admin/admin-page-title-context";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ProductEditorActionsMenu } from "@/features/admin/products/components/editor/product-editor-action-menu";
import { ProductVariantTopbarMenu } from "@/features/admin/products/components/editor/product-variant-topbar-menu";
import type {
  attachProductImagesAction,
  deleteProductImageAction,
  deleteProductVariantAction,
  reorderProductImageAction,
  setDefaultProductVariantAction,
  setProductPrimaryImageAction,
  updateProductImageAltTextAction,
  uploadProductImagesAction,
} from "@/features/admin/products/editor";
import type {
  AdminPriceListOption,
  AdminProductEditorData,
  AdminProductImageItem,
  AdminProductVariantListItem,
  AttachableMediaAssetItem,
  ProductCategoriesFormAction,
  ProductGeneralFormAction,
  ProductSeoFormAction,
  ProductVariantFormAction,
} from "@/features/admin/products/editor/types";
import { ProductCategoriesTab, type ProductCategoryOption } from "./product-categories-tab";
import { ProductGeneralTab } from "./product-general-tab";
import { ProductImagesTab } from "./product-images-tab";
import { ProductSeoTab } from "./product-seo-tab";
import { ProductVariantsTab } from "./product-variants-tab";

type SetProductPrimaryImageAction = typeof setProductPrimaryImageAction;
type UploadProductImagesAction = typeof uploadProductImagesAction;
type DeleteProductImageAction = typeof deleteProductImageAction;
type UpdateProductImageAltTextAction = typeof updateProductImageAltTextAction;
type ReorderProductImageAction = typeof reorderProductImageAction;
type AttachProductImagesAction = typeof attachProductImagesAction;
type SetDefaultProductVariantAction = typeof setDefaultProductVariantAction;
type DeleteProductVariantAction = typeof deleteProductVariantAction;

type ProductEditorTabKey = "general" | "variants" | "images" | "categories" | "seo";

type ProductEditorPanelProps = {
  generalAction: ProductGeneralFormAction;
  seoAction: ProductSeoFormAction;
  categoriesAction: ProductCategoriesFormAction;
  setPrimaryImageAction?: SetProductPrimaryImageAction;
  deleteImageAction?: DeleteProductImageAction;
  updateAltTextAction?: UpdateProductImageAltTextAction;
  reorderImageAction?: ReorderProductImageAction;
  attachImagesAction?: AttachProductImagesAction;
  createVariantAction?: ProductVariantFormAction;
  updateVariantAction?: ProductVariantFormAction;
  setDefaultVariantAction?: SetDefaultProductVariantAction;
  deleteVariantAction?: DeleteProductVariantAction;
  uploadImagesAction?: UploadProductImagesAction;
  availableCategories: ProductCategoryOption[];
  variants: AdminProductVariantListItem[];
  images: AdminProductImageItem[];
  attachableMediaItems: AttachableMediaAssetItem[];
  priceLists: AdminPriceListOption[];
  product: AdminProductEditorData;
};

function ProductEditorTabs(): JSX.Element {
  return (
    <div
      className={[
        "site-header-blur shrink-0 border-b border-shell-border",
        "px-4 pt-2 pb-1.5 md:px-6 md:pt-2.5 md:pb-2",
        "lg:bg-surface-panel-soft lg:border-surface-border/60 lg:px-5 lg:pt-3 lg:pb-0",
        "[@media(max-height:480px)]:pt-1 [@media(max-height:480px)]:pb-1",
      ].join(" ")}
    >
      <div className="no-scrollbar overflow-x-auto overflow-y-hidden">
        <TabsList className="h-auto min-w-max flex-nowrap justify-start gap-0.5 rounded-full bg-muted/30 p-0.5 lg:rounded-none lg:bg-transparent lg:p-0 lg:gap-1">
          <TabsTrigger
            className="h-8 flex-none rounded-full px-3.5 text-[11px] sm:h-9 sm:px-4 sm:text-sm lg:h-9 lg:rounded-xl lg:px-4 lg:text-sm [@media(max-height:480px)]:h-6"
            value="general"
          >
            Général
          </TabsTrigger>
          <TabsTrigger
            className="h-8 flex-none rounded-full px-3.5 text-[11px] sm:h-9 sm:px-4 sm:text-sm lg:h-9 lg:rounded-xl lg:px-4 lg:text-sm [@media(max-height:480px)]:h-6"
            value="variants"
          >
            Variantes
          </TabsTrigger>
          <TabsTrigger
            className="h-8 flex-none rounded-full px-3.5 text-[11px] sm:h-9 sm:px-4 sm:text-sm lg:h-9 lg:rounded-xl lg:px-4 lg:text-sm [@media(max-height:480px)]:h-6"
            value="images"
          >
            Galerie
          </TabsTrigger>
          <TabsTrigger
            className="h-8 flex-none rounded-full px-3.5 text-[11px] sm:h-9 sm:px-4 sm:text-sm lg:h-9 lg:rounded-xl lg:px-4 lg:text-sm [@media(max-height:480px)]:h-6"
            value="categories"
          >
            Catégories
          </TabsTrigger>
          <TabsTrigger
            className="h-8 flex-none rounded-full px-3.5 text-[11px] sm:h-9 sm:px-4 sm:text-sm lg:h-9 lg:rounded-xl lg:px-4 lg:text-sm [@media(max-height:480px)]:h-6"
            value="seo"
          >
            SEO
          </TabsTrigger>
        </TabsList>
      </div>
    </div>
  );
}

export function ProductEditorPanel({
  generalAction,
  seoAction,
  categoriesAction,
  createVariantAction,
  updateVariantAction,
  setDefaultVariantAction,
  deleteVariantAction,
  setPrimaryImageAction,
  deleteImageAction,
  updateAltTextAction,
  reorderImageAction,
  attachImagesAction,
  uploadImagesAction,
  availableCategories,
  variants,
  images,
  attachableMediaItems,
  priceLists,
  product,
}: ProductEditorPanelProps): JSX.Element {
  const { setPageActionNode } = useAdminPageTitle();
  const [activeTab, setActiveTab] = useState<ProductEditorTabKey>("general");
  const [isCreateVariantOpen, setIsCreateVariantOpen] = useState(false);

  useEffect(() => {
    if (activeTab === "variants") {
      setPageActionNode(
        <ProductVariantTopbarMenu
          productId={product.id}
          onCreateVariant={() => setIsCreateVariantOpen(true)}
        />
      );
    } else {
      setPageActionNode(<ProductEditorActionsMenu productId={product.id} />);
    }
  }, [activeTab, product.id, setPageActionNode]);

  useEffect(() => {
    return () => {
      setPageActionNode(null);
    };
  }, [setPageActionNode]);

  return (
    <div className="flex h-full min-h-0 flex-col overflow-hidden lg:rounded-2xl lg:border lg:border-surface-border lg:shadow-card lg:overflow-hidden">
      <Tabs
        value={activeTab}
        onValueChange={(value) => setActiveTab(value as ProductEditorTabKey)}
        className="flex h-full min-h-0 flex-col gap-0 overflow-hidden"
      >
        <ProductEditorTabs />

        <div className="min-h-0 flex-1 overflow-hidden">
          <TabsContent
            value="general"
            className="mt-0 flex h-full min-h-0 flex-col overflow-hidden"
          >
            <ProductGeneralTab action={generalAction} product={product} />
          </TabsContent>

          <TabsContent
            value="variants"
            className="mt-0 flex h-full min-h-0 flex-col overflow-hidden"
          >
            <ProductVariantsTab
              productId={product.id}
              productSlug={product.slug}
              variants={variants}
              images={images}
              priceLists={priceLists}
              createDialogOpen={isCreateVariantOpen}
              onCreateDialogOpenChange={setIsCreateVariantOpen}
              {...(createVariantAction ? { createAction: createVariantAction } : {})}
              {...(updateVariantAction ? { updateAction: updateVariantAction } : {})}
              {...(setDefaultVariantAction ? { setDefaultAction: setDefaultVariantAction } : {})}
              {...(deleteVariantAction ? { deleteAction: deleteVariantAction } : {})}
            />
          </TabsContent>

          <TabsContent value="images" className="mt-0 flex h-full min-h-0 flex-col overflow-hidden">
            <ProductImagesTab
              productId={product.id}
              productSlug={product.slug}
              images={images}
              attachableMediaItems={attachableMediaItems}
              {...(setPrimaryImageAction ? { setPrimaryImageAction } : {})}
              {...(deleteImageAction ? { deleteImageAction } : {})}
              {...(updateAltTextAction ? { updateAltTextAction } : {})}
              {...(reorderImageAction ? { reorderImageAction } : {})}
              {...(attachImagesAction ? { attachImagesAction } : {})}
              {...(uploadImagesAction ? { uploadImagesAction } : {})}
            />
          </TabsContent>

          <TabsContent
            value="categories"
            className="mt-0 flex h-full min-h-0 flex-col overflow-hidden"
          >
            <ProductCategoriesTab
              action={categoriesAction}
              product={product}
              availableCategories={availableCategories}
            />
          </TabsContent>

          <TabsContent value="seo" className="mt-0 flex h-full min-h-0 flex-col overflow-hidden">
            <ProductSeoTab action={seoAction} product={product} />
          </TabsContent>
        </div>
      </Tabs>
    </div>
  );
}
