"use client";

import { useActionState, useState, type JSX } from "react";

import { AdminFormSection } from "@/components/admin/forms/admin-form-section";
import { Button } from "@/components/ui/button";
import type { AdminProductEditorData } from "@/features/admin/products/editor";
import { useProductCategoriesManager } from "@/features/admin/products/editor/hooks";
import type { ProductCategoryOption } from "@/features/admin/products/editor/types/product-categories.types";
import {
  productCategoriesFormInitialState,
  type ProductCategoriesFormAction,
} from "@/features/admin/products/editor/types";
import {
  ProductCategoriesAddFields,
  ProductCategoriesLinkedList,
  ProductCategoriesPrimaryFields,
  ProductCategoriesSummary,
} from "./categories";
import { AdminFormMessage } from "@/components/admin/forms/admin-form-message";
import { AdminFormFooter } from "@/components/admin/forms/admin-form-footer";

type ProductCategoriesTabProps = {
  action: ProductCategoriesFormAction;
  product: AdminProductEditorData;
  availableCategories: ProductCategoryOption[];
};

type ProductCategoriesTabInnerProps = ProductCategoriesTabProps & {
  onReset: () => void;
};

function ProductCategoriesTabInner({
  action,
  product,
  availableCategories,
  onReset,
}: ProductCategoriesTabInnerProps): JSX.Element {
  const [state, formAction, pending] = useActionState(action, productCategoriesFormInitialState);

  const manager = useProductCategoriesManager({
    availableCategories,
    initialCategoryIds: product.categoryIds,
    initialPrimaryCategoryId: product.primaryCategoryId,
  });

  return (
    <form action={formAction} className="flex h-full min-h-0 flex-col overflow-hidden">
      <input type="hidden" name="id" value={product.id} />
      <input type="hidden" name="primaryCategoryId" value={manager.primaryCategoryId} />

      {manager.linkedCategoryIds.map((categoryId) => (
        <input key={categoryId} type="hidden" name="categoryIds" value={categoryId} />
      ))}

      <div className="min-h-0 flex-1 overflow-y-auto">
        <div className="w-full space-y-5 px-4 pt-4 pb-4 md:space-y-8 md:px-6 md:pt-6 md:pb-6 lg:mx-auto lg:max-w-3xl lg:px-0 [@media(max-height:480px)]:space-y-4 [@media(max-height:480px)]:pt-3 [@media(max-height:480px)]:pb-3">
          <AdminFormMessage
            tone={state.status === "error" ? "error" : "success"}
            message={state.status !== "idle" ? state.message : null}
          />

          <AdminFormSection
            title="Catégories"
            description="Associer ce produit à une ou plusieurs catégories du catalogue et définir la catégorie principale la plus précise."
          >
            <ProductCategoriesSummary
              linkedCount={manager.linkedCategoryIds.length}
              primaryLabel={manager.primaryCategorySummary}
            />

            <ProductCategoriesPrimaryFields
              rootCategories={manager.rootCategories}
              primaryRootId={manager.primaryRootId}
              primaryChildValue={manager.primaryChildValue}
              primaryRootChildren={manager.primaryRootChildren}
              rootCategorySentinel={manager.rootCategorySentinel}
              error={state.fieldErrors.primaryCategoryId}
              onPrimaryRootChange={manager.handlePrimaryRootChange}
              onPrimaryChildChange={manager.handlePrimaryChildChange}
            />

            <ProductCategoriesAddFields
              rootCategories={manager.rootCategories}
              categoryToAddRootId={manager.categoryToAddRootId}
              categoryToAddChildId={manager.categoryToAddChildId}
              addRootChildren={manager.addRootChildren}
              error={state.fieldErrors.categoryIds}
              onAddRootChange={manager.handleAddRootChange}
              onAddChildChange={manager.handleAddChildChange}
              onAddCategory={manager.handleAddCategory}
            />

            <ProductCategoriesLinkedList
              linkedCategories={manager.linkedCategories}
              linkedCategoryIds={manager.linkedCategoryIds}
              primaryCategoryId={manager.primaryCategoryId}
              childrenByParentId={manager.childrenByParentId}
              onRemoveCategory={manager.handleRemoveCategory}
            />
          </AdminFormSection>
        </div>
      </div>

      <AdminFormFooter actionsClassName="w-full justify-between gap-2 sm:w-auto sm:justify-end">
        <Button
          variant="ghost"
          type="button"
          className="h-10 shrink-0 rounded-full px-4 text-muted-foreground hover:text-foreground lg:h-9"
          onClick={onReset}
        >
          Réinitialiser
        </Button>

        <Button
          type="submit"
          variant="outline"
          className="h-10 min-w-[10rem] flex-1 rounded-full border-shell-border bg-background/70 px-4 text-foreground shadow-none sm:flex-none lg:h-9"
          disabled={pending}
        >
          {pending ? "Mise à jour…" : "Enregistrer les catégories"}
        </Button>
      </AdminFormFooter>
    </form>
  );
}

export function ProductCategoriesTab(props: ProductCategoriesTabProps): JSX.Element {
  const [formInstanceKey, setFormInstanceKey] = useState(0);

  return (
    <ProductCategoriesTabInner
      key={formInstanceKey}
      {...props}
      onReset={() => setFormInstanceKey((current) => current + 1)}
    />
  );
}

export type { ProductCategoryOption } from "@/features/admin/products/editor/types/product-categories.types";
