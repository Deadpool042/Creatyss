"use client";

import { useState, type JSX } from "react";
import { Images, Upload } from "lucide-react";

import { AdminFormMessage } from "@/components/admin/forms/admin-form-message";
import { AdminFormSection } from "@/components/admin/forms/admin-form-section";
import { Button } from "@/components/ui/button";
import type {
  AdminProductImageItem,
  AttachableMediaAssetItem,
} from "@/features/admin/products/editor/types";
import type {
  attachProductImagesAction,
  deleteProductImageAction,
  reorderProductImageAction,
  setProductPrimaryImageAction,
  updateProductImageAltTextAction,
  uploadProductImagesAction,
} from "@/features/admin/products/editor";
import { ProductImageGallery } from "./images/product-image-gallery";
import { ProductImageLibrarySheet } from "./images/product-image-library-sheet";
import { ProductImageUploadForm } from "./images/product-image-upload-form";

type SetProductPrimaryImageAction = typeof setProductPrimaryImageAction;
type DeleteProductImageAction = typeof deleteProductImageAction;
type UploadProductImagesAction = typeof uploadProductImagesAction;
type UpdateProductImageAltTextAction = typeof updateProductImageAltTextAction;
type ReorderProductImageAction = typeof reorderProductImageAction;
type AttachProductImagesAction = typeof attachProductImagesAction;

type MessageState = {
  status: "success" | "error";
  message: string;
} | null;

type ProductImagesTabProps = {
  productId: string;
  productSlug: string;
  images: AdminProductImageItem[];
  attachableMediaItems?: AttachableMediaAssetItem[];
  setPrimaryImageAction?: SetProductPrimaryImageAction;
  deleteImageAction?: DeleteProductImageAction;
  uploadImagesAction?: UploadProductImagesAction;
  updateAltTextAction?: UpdateProductImageAltTextAction;
  reorderImageAction?: ReorderProductImageAction;
  attachImagesAction?: AttachProductImagesAction;
};

export function ProductImagesTab({
  productId,
  productSlug,
  images,
  attachableMediaItems = [],
  setPrimaryImageAction,
  deleteImageAction,
  uploadImagesAction,
  updateAltTextAction,
  reorderImageAction,
  attachImagesAction,
}: ProductImagesTabProps): JSX.Element {
  const [messageState, setMessageState] = useState<MessageState>(null);
  const [showUploadForm, setShowUploadForm] = useState(false);
  const [libraryOpen, setLibraryOpen] = useState(false);

  const primaryImage = images.find((image) => image.isPrimary) ?? null;

  async function handleSetPrimary(
    assetId: string
  ): Promise<{ status: "success" | "error"; message: string }> {
    if (!setPrimaryImageAction) {
      return {
        status: "error",
        message: "Action indisponible.",
      };
    }

    const result = await setPrimaryImageAction({ productId, assetId });
    setMessageState(result);
    return result;
  }

  async function handleDelete(
    assetId: string
  ): Promise<{ status: "success" | "error"; message: string }> {
    if (!deleteImageAction) {
      return {
        status: "error",
        message: "Action indisponible.",
      };
    }

    const result = await deleteImageAction({
      productId,
      assetId,
    });

    setMessageState(result);
    return result;
  }

  async function handleUpdateAltText(
    assetId: string,
    altText: string
  ): Promise<{ status: "success" | "error"; message: string }> {
    if (!updateAltTextAction) {
      return {
        status: "error",
        message: "Action indisponible.",
      };
    }

    const result = await updateAltTextAction({
      productId,
      assetId,
      altText,
    });

    setMessageState(result);
    return result;
  }

  async function handleReorder(
    assetId: string,
    direction: "up" | "down"
  ): Promise<{ status: "success" | "error"; message: string }> {
    if (!reorderImageAction) {
      return {
        status: "error",
        message: "Action indisponible.",
      };
    }

    const result = await reorderImageAction({
      productId,
      assetId,
      direction,
    });

    setMessageState(result);
    return result;
  }

  async function handleAttach(
    assetIds: string[]
  ): Promise<{ status: "success" | "error"; message: string }> {
    if (!attachImagesAction) {
      return {
        status: "error",
        message: "Action indisponible.",
      };
    }

    const result = await attachImagesAction({
      productId,
      assetIds,
    });

    setMessageState(result);
    return result;
  }

  return (
    <div className="flex h-full flex-col overflow-hidden">
      <div className="min-h-0 flex-1 overflow-y-auto">
        <div className="w-full space-y-5 px-4 pt-4 pb-3 md:space-y-8 md:px-6 md:pt-6 md:pb-6 lg:mx-auto lg:max-w-6xl lg:px-0 [@media(max-height:480px)]:space-y-4 [@media(max-height:480px)]:pt-3 [@media(max-height:480px)]:pb-2.5">
          <AdminFormMessage
            tone={messageState?.status === "success" ? "success" : "error"}
            message={messageState?.message ?? null}
          />

          <AdminFormSection
            title="Galerie produit"
            description="Gère les images visibles sur la fiche produit, leur ordre d’affichage sur la boutique et l’image principale du produit."
          >
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="text-sm text-muted-foreground">
                {images.length} image{images.length > 1 ? "s" : ""}
              </div>

              <div className="flex flex-wrap items-center gap-2">
                {attachImagesAction ? (
                  <Button
                    type="button"
                    size="sm"
                    variant="outline"
                    onClick={() => setLibraryOpen(true)}
                  >
                    <Images className="mr-2 h-4 w-4" />
                    Associer depuis les médias
                  </Button>
                ) : null}

                {uploadImagesAction ? (
                  <Button
                    type="button"
                    size="sm"
                    variant={showUploadForm ? "secondary" : "default"}
                    onClick={() => setShowUploadForm((current) => !current)}
                  >
                    <Upload className="mr-2 h-4 w-4" />
                    {showUploadForm ? "Fermer l’import" : "Ajouter une image"}
                  </Button>
                ) : (
                  <Button type="button" size="sm" disabled>
                    <Upload className="mr-2 h-4 w-4" />
                    Ajouter une image
                  </Button>
                )}
              </div>
            </div>

            {showUploadForm && uploadImagesAction ? (
              <div className="rounded-2xl border border-border/60 bg-muted/10 p-4">
                <ProductImageUploadForm productId={productId} action={uploadImagesAction} />
              </div>
            ) : null}

            {primaryImage ? (
              <div className="rounded-xl border border-border/60 px-4 py-3 text-sm">
                <span className="font-medium">Image principale du produit : </span>
                <span className="text-muted-foreground">
                  {primaryImage.altText ?? primaryImage.assetId}
                </span>
              </div>
            ) : (
              <div className="rounded-xl border border-dashed px-4 py-3 text-sm text-muted-foreground">
                Aucune image principale du produit n’est définie.
              </div>
            )}

            <ProductImageGallery
              productId={productId}
              images={images}
              {...(setPrimaryImageAction ? { onSetPrimary: handleSetPrimary } : {})}
              {...(deleteImageAction ? { onDelete: handleDelete } : {})}
              {...(updateAltTextAction ? { onUpdateAltText: handleUpdateAltText } : {})}
              {...(reorderImageAction ? { onReorder: handleReorder } : {})}
            />

            <ProductImageLibrarySheet
              open={libraryOpen}
              onOpenChange={setLibraryOpen}
              items={attachableMediaItems}
              {...(attachImagesAction ? { onAttach: handleAttach } : {})}
            />
          </AdminFormSection>

          <AdminFormSection
            title="Informations techniques"
            description="Vue de contrôle rapide de la galerie produit et de son affichage sur la boutique."
          >
            <div className="grid gap-3 text-sm text-muted-foreground md:grid-cols-3">
              <div className="rounded-lg border border-border/60 px-4 py-3">
                <p className="text-[11px] uppercase tracking-wide">Produit</p>
                <p className="mt-1 font-medium text-foreground">{productSlug}</p>
              </div>

              <div className="rounded-lg border border-border/60 px-4 py-3">
                <p className="text-[11px] uppercase tracking-wide">Identifiant produit</p>
                <p className="mt-1 truncate font-medium text-foreground">{productId}</p>
              </div>

              <div className="rounded-lg border border-border/60 px-4 py-3">
                <p className="text-[11px] uppercase tracking-wide">Image principale</p>
                <p className="mt-1 font-medium text-foreground">
                  {primaryImage ? "Définie" : "Aucune"}
                </p>
              </div>
            </div>
          </AdminFormSection>
        </div>
      </div>
    </div>
  );
}
