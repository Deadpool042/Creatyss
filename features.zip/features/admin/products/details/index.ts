export { ProductDetailsPanel, ProductDetails } from "./components";
export { mapProductDetails } from "./mappers/map-product-details";
export { readAdminProductDetailsBySlug } from "./queries";
export type {
  AdminProductDetails,
  AdminProductDetailsCategory,
  AdminProductDetailsDiagnostics,
  AdminProductDetailsVariant,
  AdminProductDetailsVariantOptionValue,
  AdminProductDisplayStatus,
  AdminProductDisplayType,
} from "./types/product-detail-types";
