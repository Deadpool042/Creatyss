import { db } from "@/core/db";
import { mapProductDetails } from "@/features/admin/products/details/mappers/map-product-details";
import type { AdminProductDetails } from "@/features/admin/products/details/types/product-detail-types";

type ReadAdminProductDetailsBySlugInput = {
  slug: string;
};

export async function readAdminProductDetailsBySlug(
  input: ReadAdminProductDetailsBySlugInput
): Promise<AdminProductDetails | null> {
  const product = await db.product.findFirst({
    where: {
      slug: input.slug,
      archivedAt: null,
    },
    select: {
      id: true,
      slug: true,
      name: true,
      shortDescription: true,
      description: true,
      status: true,
      isFeatured: true,
      updatedAt: true,
      productType: {
        select: {
          code: true,
        },
      },
      primaryImage: {
        select: {
          publicUrl: true,
          altText: true,
        },
      },
      productCategories: {
        where: {
          archivedAt: null,
          category: {
            archivedAt: null,
          },
        },
        orderBy: [
          { isPrimary: "desc" },
          { sortOrder: "asc" },
          { createdAt: "asc" },
        ],
        select: {
          isPrimary: true,
          sortOrder: true,
          category: {
            select: {
              id: true,
              slug: true,
              name: true,
            },
          },
        },
      },
      prices: {
        where: {
          archivedAt: null,
        },
        orderBy: [{ createdAt: "asc" }],
        take: 1,
        select: {
          amount: true,
          compareAtAmount: true,
        },
      },
      variants: {
        where: {
          archivedAt: null,
        },
        orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
        select: {
          id: true,
          slug: true,
          name: true,
          sku: true,
          status: true,
          primaryImage: {
            select: {
              publicUrl: true,
              altText: true,
            },
          },
          prices: {
            where: {
              archivedAt: null,
            },
            orderBy: [{ createdAt: "asc" }],
            take: 1,
            select: {
              amount: true,
              compareAtAmount: true,
            },
          },
          optionValues: {
            where: {
              archivedAt: null,
              optionValue: {
                archivedAt: null,
                option: {
                  archivedAt: null,
                },
              },
            },
            orderBy: [{ createdAt: "asc" }],
            select: {
              optionValue: {
                select: {
                  value: true,
                  label: true,
                  option: {
                    select: {
                      name: true,
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
  });

  if (product === null) {
    return null;
  }

  return mapProductDetails(product);
}
