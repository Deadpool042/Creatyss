export { AdminProductEditorServiceError } from "./shared/error";

export {
  mapEditorStatusToPrismaStatus,
  mapEditorVariantStatusToPrismaStatus,
  mapEditorAvailabilityStatusToPrismaStatus,
} from "./shared/status-mappers";

export {
  mapEditorRelatedTypeToPrismaType,
  mapEditorSubjectTypeToPrismaSubjectType,
  mapEditorRoleToPrismaRole,
} from "./shared/relation-mappers";

export {
  assertProductExists,
  assertProductIsVariable,
  assertMediaAssetExists,
  assertProductTypeExists,
  assertCategoriesExist,
} from "./shared/product-assertions";

export {
  assertVariantExists,
  assertVariantAxisCombinationIsUnique,
  assertDefaultVariantWouldRemain,
  ensureDefaultVariantExists,
  assertVariantOptionValuesAreValid,
} from "./shared/variant-assertions";

export { assertRelatedProductsExist } from "./shared/related-product-assertions";
