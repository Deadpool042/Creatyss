import { db } from "@/core/db";
import type { AttachableMediaAssetItem, AttachableMediaAssetsData } from "../types";

type ListAttachableMediaAssetsInput = {
  productId: string;
};

export async function listAttachableMediaAssets(
  input: ListAttachableMediaAssetsInput
): Promise<AttachableMediaAssetsData> {
  const product = await db.product.findFirst({
    where: {
      id: input.productId,
      archivedAt: null,
    },
    select: {
      id: true,
      slug: true,
      storeId: true,
    },
  });

  if (product === null) {
    return {
      productId: input.productId,
      productSlug: "",
      items: [],
    };
  }

  const assets = await db.mediaAsset.findMany({
    where: {
      storeId: product.storeId,
      archivedAt: null,
    },
    orderBy: [
      { createdAt: "desc" },
    ],
    select: {
      id: true,
      publicUrl: true,
      storageKey: true,
      altText: true,
      originalName: true,
      mimeType: true,
    },
  });

  const items: AttachableMediaAssetItem[] = assets.map((asset) => ({
    id: asset.id,
    publicUrl: asset.publicUrl,
    storageKey: asset.storageKey,
    altText: asset.altText,
    originalName: asset.originalName,
    mimeType: asset.mimeType,
  }));

  return {
    productId: product.id,
    productSlug: product.slug ?? "",
    items,
  };
}
