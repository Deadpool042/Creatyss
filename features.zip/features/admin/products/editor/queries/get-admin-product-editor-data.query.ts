import { db } from "@/core/db";
import type {
  AdminProductEditorData,
  AdminProductImageItem,
  AdminProductVariantListItem,
} from "@/features/admin/products/editor/types";

type GetAdminProductEditorDataInput = {
  productId: string;
};

export async function getAdminProductEditorData(
  input: GetAdminProductEditorDataInput
): Promise<AdminProductEditorData | null> {
  const product = await db.product.findFirst({
    where: {
      id: input.productId,
      archivedAt: null,
    },
    select: {
      id: true,
      slug: true,
      name: true,
      skuRoot: true,
      shortDescription: true,
      description: true,
      status: true,
      isFeatured: true,
      isStandalone: true,
      productTypeId: true,
      productType: {
        select: {
          id: true,
          code: true,
          name: true,
          slug: true,
          isActive: true,
        },
      },
      primaryImageId: true,
      primaryImage: {
        select: {
          id: true,
          publicUrl: true,
          storageKey: true,
          altText: true,
          originalName: true,
          mimeType: true,
        },
      },
      productCategories: {
        where: {
          archivedAt: null,
          category: {
            archivedAt: null,
          },
        },
        orderBy: [
          { isPrimary: "desc" },
          { sortOrder: "asc" },
          { createdAt: "asc" },
        ],
        select: {
          id: true,
          categoryId: true,
          isPrimary: true,
          sortOrder: true,
          category: {
            select: {
              id: true,
              name: true,
              slug: true,
            },
          },
        },
      },
      relatedFrom: {
        where: {
          archivedAt: null,
          targetProduct: {
            archivedAt: null,
          },
        },
        orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
        select: {
          id: true,
          targetProductId: true,
          type: true,
          sortOrder: true,
          targetProduct: {
            select: {
              id: true,
              name: true,
              slug: true,
            },
          },
        },
      },
      variants: {
        where: {
          archivedAt: null,
        },
        orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
        select: {
          id: true,
          slug: true,
          sku: true,
          name: true,
          status: true,
          isDefault: true,
          sortOrder: true,
          barcode: true,
          externalReference: true,
          weightGrams: true,
          widthMm: true,
          heightMm: true,
          depthMm: true,
          primaryImageId: true,
          primaryImage: {
            select: {
              id: true,
              publicUrl: true,
              storageKey: true,
              altText: true,
              originalName: true,
              mimeType: true,
            },
          },
        },
      },
      mediaReferences: {
        where: {
          archivedAt: null,
          mediaAsset: {
            archivedAt: null,
          },
        },
        orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
        select: {
          id: true,
          subjectType: true,
          subjectId: true,
          role: true,
          sortOrder: true,
          isPrimary: true,
          mediaAssetId: true,
          mediaAsset: {
            select: {
              id: true,
              publicUrl: true,
              storageKey: true,
              altText: true,
              originalName: true,
              mimeType: true,
            },
          },
        },
      },
    },
  });

  if (product === null) {
    return null;
  }

  const variants: AdminProductVariantListItem[] = product.variants.map((variant) => ({
    id: variant.id,
    slug: variant.slug,
    sku: variant.sku,
    name: variant.name,
    status:
      variant.status === "ACTIVE"
        ? "active"
        : variant.status === "INACTIVE"
          ? "inactive"
          : variant.status === "ARCHIVED"
            ? "archived"
            : "draft",
    isDefault: variant.isDefault,
    sortOrder: variant.sortOrder,
    barcode: variant.barcode,
    externalReference: variant.externalReference,
    weightGrams: variant.weightGrams?.toString() ?? null,
    widthMm: variant.widthMm?.toString() ?? null,
    heightMm: variant.heightMm?.toString() ?? null,
    depthMm: variant.depthMm?.toString() ?? null,
    primaryImageId: variant.primaryImageId,
    primaryImageUrl: variant.primaryImage?.publicUrl ?? null,
    primaryImageStorageKey: variant.primaryImage?.storageKey ?? null,
    primaryImageAltText: variant.primaryImage?.altText ?? null,
  }));

  const images: AdminProductImageItem[] = product.mediaReferences.map((reference) => ({
    id: reference.id,
    mediaAssetId: reference.mediaAssetId,
    subjectType:
      reference.subjectType === "PRODUCT_VARIANT" ? "product_variant" : "product",
    subjectId: reference.subjectId,
    role:
      reference.role === "THUMBNAIL"
        ? "thumbnail"
        : reference.role === "OTHER"
          ? "other"
          : "gallery",
    sortOrder: reference.sortOrder,
    isPrimary: reference.isPrimary,
    publicUrl: reference.mediaAsset.publicUrl,
    storageKey: reference.mediaAsset.storageKey,
    altText: reference.mediaAsset.altText,
    originalName: reference.mediaAsset.originalName,
    mimeType: reference.mediaAsset.mimeType,
  }));

  return {
    product: {
      id: product.id,
      slug: product.slug ?? "",
      name: product.name,
      skuRoot: product.skuRoot,
      shortDescription: product.shortDescription,
      description: product.description,
      status:
        product.status === "ACTIVE"
          ? "active"
          : product.status === "INACTIVE"
            ? "inactive"
            : product.status === "ARCHIVED"
              ? "archived"
              : "draft",
      isFeatured: product.isFeatured,
      isStandalone: product.isStandalone,
      productTypeId: product.productTypeId,
      productTypeCode: product.productType?.code ?? null,
      primaryImageId: product.primaryImageId,
      primaryImageUrl: product.primaryImage?.publicUrl ?? null,
      primaryImageStorageKey: product.primaryImage?.storageKey ?? null,
      primaryImageAltText: product.primaryImage?.altText ?? null,
      categoryLinks: product.productCategories.map((link) => ({
        id: link.id,
        categoryId: link.categoryId,
        categoryName: link.category.name,
        categorySlug: link.category.slug,
        isPrimary: link.isPrimary,
        sortOrder: link.sortOrder,
      })),
      relatedProducts: product.relatedFrom.map((link) => ({
        id: link.id,
        targetProductId: link.targetProductId,
        targetProductName: link.targetProduct.name,
        targetProductSlug: link.targetProduct.slug,
        type:
          link.type === "CROSS_SELL"
            ? "cross_sell"
            : link.type === "UP_SELL"
              ? "up_sell"
              : link.type === "ACCESSORY"
                ? "accessory"
                : link.type === "SIMILAR"
                  ? "similar"
                  : "related",
        sortOrder: link.sortOrder,
      })),
    },
    variants,
    images,
  };
}
