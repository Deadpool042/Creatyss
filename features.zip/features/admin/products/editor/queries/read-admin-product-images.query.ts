import { db } from "@/core/db";
import type { AdminProductImagesData } from "../types";
import { getAdminProductEditorData } from "./get-admin-product-editor-data.query";

type ReadAdminProductImagesInput = {
  slug: string;
};

export async function readAdminProductImages(
  input: ReadAdminProductImagesInput
): Promise<AdminProductImagesData | null> {
  const product = await db.product.findFirst({
    where: {
      slug: input.slug,
      archivedAt: null,
    },
    select: {
      id: true,
      slug: true,
      primaryImageId: true,
    },
  });

  if (product === null) {
    return null;
  }

  const editorData = await getAdminProductEditorData({
    productId: product.id,
  });

  if (editorData === null) {
    return null;
  }

  return {
    productId: editorData.product.id,
    productSlug: editorData.product.slug,
    primaryImageId: editorData.product.primaryImageId,
    images: editorData.images,
  };
}
