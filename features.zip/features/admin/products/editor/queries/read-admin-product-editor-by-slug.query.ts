import { db } from "@/core/db";
import type { AdminProductEditorData } from "../types";
import { getAdminProductEditorData } from "./get-admin-product-editor-data.query";

type ReadAdminProductEditorBySlugInput = {
  slug: string;
};

export async function readAdminProductEditorBySlug(
  input: ReadAdminProductEditorBySlugInput
): Promise<AdminProductEditorData | null> {
  const product = await db.product.findFirst({
    where: {
      slug: input.slug,
      archivedAt: null,
    },
    select: {
      id: true,
    },
  });

  if (product === null) {
    return null;
  }

  return getAdminProductEditorData({
    productId: product.id,
  });
}
