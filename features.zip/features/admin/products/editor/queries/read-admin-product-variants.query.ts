import { db } from "@/core/db";
import type { AdminProductVariantEditorData } from "../types";
import { getAdminProductEditorData } from "./get-admin-product-editor-data.query";

type ReadAdminProductVariantsInput = {
  slug: string;
};

export async function readAdminProductVariants(
  input: ReadAdminProductVariantsInput
): Promise<AdminProductVariantEditorData | null> {
  const product = await db.product.findFirst({
    where: {
      slug: input.slug,
      archivedAt: null,
    },
    select: {
      id: true,
      slug: true,
    },
  });

  if (product === null) {
    return null;
  }

  const editorData = await getAdminProductEditorData({
    productId: product.id,
  });

  if (editorData === null) {
    return null;
  }

  return {
    productId: editorData.product.id,
    productSlug: editorData.product.slug,
    variants: editorData.variants,
  };
}
