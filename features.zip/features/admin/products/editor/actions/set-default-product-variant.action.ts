"use server";

import {
  AdminProductEditorServiceError,
  setDefaultProductVariant,
} from "../services";
import type {
  SetDefaultProductVariantInput,
  SetDefaultProductVariantResult,
} from "../types";

export async function setDefaultProductVariantAction(
  input: SetDefaultProductVariantInput
): Promise<SetDefaultProductVariantResult> {
  try {
    await setDefaultProductVariant({
      productId: input.productId,
      variantId: input.variantId,
    });

    return {
      status: "success",
      message: "Variante par défaut mise à jour.",
    };
  } catch (error: unknown) {
    if (error instanceof AdminProductEditorServiceError) {
      return {
        status: "error",
        message: "Impossible de définir la variante par défaut.",
      };
    }

    return {
      status: "error",
      message: "Une erreur inattendue est survenue.",
    };
  }
}
