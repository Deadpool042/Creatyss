"use server";

import {
  attachProductImages,
  AdminProductEditorServiceError,
} from "../services";
import type { AttachProductImagesInput, AttachProductImagesResult } from "../types";

export async function attachProductImagesAction(
  input: AttachProductImagesInput
): Promise<AttachProductImagesResult> {
  try {
    await attachProductImages({
      images: input.images,
    });

    return {
      status: "success",
      message: "Images rattachées.",
    };
  } catch (error: unknown) {
    if (error instanceof AdminProductEditorServiceError) {
      return {
        status: "error",
        message: "Le rattachement des images a échoué.",
      };
    }

    return {
      status: "error",
      message: "Une erreur inattendue est survenue.",
    };
  }
}
