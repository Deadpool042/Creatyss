"use server";

import {
  AdminProductEditorServiceError,
  deleteProductImage,
} from "../services";
import type { DeleteProductImageInput, DeleteProductImageResult } from "../types";

export async function deleteProductImageAction(
  input: DeleteProductImageInput
): Promise<DeleteProductImageResult> {
  try {
    await deleteProductImage({
      productId: input.productId,
      imageId: input.imageId,
    });

    return {
      status: "success",
      message: "Image supprimée.",
    };
  } catch (error: unknown) {
    if (error instanceof AdminProductEditorServiceError) {
      return {
        status: "error",
        message: "La suppression de l'image a échoué.",
      };
    }

    return {
      status: "error",
      message: "Une erreur inattendue est survenue.",
    };
  }
}
