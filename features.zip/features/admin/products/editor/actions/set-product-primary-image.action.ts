"use server";

import {
  AdminProductEditorServiceError,
  setProductPrimaryImage,
} from "../services";
import type {
  SetProductPrimaryImageInput,
  SetProductPrimaryImageResult,
} from "../types";

export async function setProductPrimaryImageAction(
  input: SetProductPrimaryImageInput
): Promise<SetProductPrimaryImageResult> {
  try {
    await setProductPrimaryImage({
      productId: input.productId,
      mediaAssetId: input.mediaAssetId,
    });

    return {
      status: "success",
      message: "Image principale mise à jour.",
    };
  } catch (error: unknown) {
    if (error instanceof AdminProductEditorServiceError) {
      return {
        status: "error",
        message: "Impossible de changer l'image principale.",
      };
    }

    return {
      status: "error",
      message: "Une erreur inattendue est survenue.",
    };
  }
}
