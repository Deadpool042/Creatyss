"use server";

import {
  AdminProductEditorServiceError,
  reorderProductImage,
} from "../services";
import type { ReorderProductImageInput, ReorderProductImageResult } from "../types";

export async function reorderProductImageAction(
  input: ReorderProductImageInput
): Promise<ReorderProductImageResult> {
  try {
    await reorderProductImage({
      productId: input.productId,
      imageId: input.imageId,
      sortOrder: input.sortOrder,
    });

    return {
      status: "success",
      message: "Ordre des images mis à jour.",
    };
  } catch (error: unknown) {
    if (error instanceof AdminProductEditorServiceError) {
      return {
        status: "error",
        message: "Impossible de réordonner l'image.",
      };
    }

    return {
      status: "error",
      message: "Une erreur inattendue est survenue.",
    };
  }
}
