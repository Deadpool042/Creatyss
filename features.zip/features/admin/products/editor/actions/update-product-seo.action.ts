"use server";

import { revalidatePath } from "next/cache";
import { SeoSubjectType, MediaReferenceSubjectType } from "@/prisma-generated/client";

import { db } from "@/core/db";
import { updateProductSeoSchema } from "@/features/admin/products/editor/schemas";
import type {
  ProductSeoFormState,
  ProductSeoFormValues,
} from "@/features/admin/products/editor/types";

function mapFormDataToValues(formData: FormData): ProductSeoFormValues {
  const seoCanonicalPathRaw = String(formData.get("seoCanonicalPath") ?? "").trim();
  const seoOpenGraphImageIdRaw = String(formData.get("seoOpenGraphImageId") ?? "").trim();

  return {
    id: String(formData.get("id") ?? ""),
    seoTitle: String(formData.get("seoTitle") ?? ""),
    seoDescription: String(formData.get("seoDescription") ?? ""),
    seoIndexingMode:
      (String(formData.get("seoIndexingMode") ?? "") as ProductSeoFormValues["seoIndexingMode"]) ||
      "INDEX_FOLLOW",
    seoSitemapIncluded: String(formData.get("seoSitemapIncluded") ?? "true") === "true",
    seoCanonicalPath: seoCanonicalPathRaw.length > 0 ? seoCanonicalPathRaw : null,
    seoOpenGraphTitle: String(formData.get("seoOpenGraphTitle") ?? ""),
    seoOpenGraphDescription: String(formData.get("seoOpenGraphDescription") ?? ""),
    seoOpenGraphImageId: seoOpenGraphImageIdRaw.length > 0 ? seoOpenGraphImageIdRaw : null,
  };
}

function buildFieldErrors(input: {
  id?: string | undefined;
  seoTitle?: string | undefined;
  seoDescription?: string | undefined;
  seoIndexingMode?: string | undefined;
  seoSitemapIncluded?: string | undefined;
  seoCanonicalPath?: string | undefined;
  seoOpenGraphTitle?: string | undefined;
  seoOpenGraphDescription?: string | undefined;
  seoOpenGraphImageId?: string | undefined;
}): ProductSeoFormState["fieldErrors"] {
  const fieldErrors: ProductSeoFormState["fieldErrors"] = {};

  if (input.id) {
    fieldErrors.id = input.id;
  }
  if (input.seoTitle) {
    fieldErrors.seoTitle = input.seoTitle;
  }
  if (input.seoDescription) {
    fieldErrors.seoDescription = input.seoDescription;
  }
  if (input.seoIndexingMode) {
    fieldErrors.seoIndexingMode = input.seoIndexingMode;
  }
  if (input.seoSitemapIncluded) {
    fieldErrors.seoSitemapIncluded = input.seoSitemapIncluded;
  }
  if (input.seoCanonicalPath) {
    fieldErrors.seoCanonicalPath = input.seoCanonicalPath;
  }
  if (input.seoOpenGraphTitle) {
    fieldErrors.seoOpenGraphTitle = input.seoOpenGraphTitle;
  }
  if (input.seoOpenGraphDescription) {
    fieldErrors.seoOpenGraphDescription = input.seoOpenGraphDescription;
  }
  if (input.seoOpenGraphImageId) {
    fieldErrors.seoOpenGraphImageId = input.seoOpenGraphImageId;
  }

  return fieldErrors;
}

export async function updateProductSeoAction(
  _previousState: ProductSeoFormState,
  formData: FormData
): Promise<ProductSeoFormState> {
  const rawValues = mapFormDataToValues(formData);
  const parsed = updateProductSeoSchema.safeParse(rawValues);

  if (!parsed.success) {
    const issues = parsed.error.issues;

    return {
      status: "error",
      message: "Le formulaire SEO contient des erreurs.",
      fieldErrors: buildFieldErrors({
        id: issues.find((issue) => issue.path[0] === "id")?.message,
        seoTitle: issues.find((issue) => issue.path[0] === "seoTitle")?.message,
        seoDescription: issues.find((issue) => issue.path[0] === "seoDescription")?.message,
        seoIndexingMode: issues.find((issue) => issue.path[0] === "seoIndexingMode")?.message,
        seoSitemapIncluded: issues.find((issue) => issue.path[0] === "seoSitemapIncluded")?.message,
        seoCanonicalPath: issues.find((issue) => issue.path[0] === "seoCanonicalPath")?.message,
        seoOpenGraphTitle: issues.find((issue) => issue.path[0] === "seoOpenGraphTitle")?.message,
        seoOpenGraphDescription: issues.find((issue) => issue.path[0] === "seoOpenGraphDescription")
          ?.message,
        seoOpenGraphImageId: issues.find((issue) => issue.path[0] === "seoOpenGraphImageId")
          ?.message,
      }),
    };
  }

  const product = await db.product.findUnique({
    where: {
      id: parsed.data.id,
    },
    select: {
      id: true,
      slug: true,
      storeId: true,
    },
  });

  if (!product) {
    return {
      status: "error",
      message: "Le produit demandé est introuvable.",
      fieldErrors: buildFieldErrors({
        id: "Produit introuvable.",
      }),
    };
  }

  if (parsed.data.seoOpenGraphImageId !== null) {
    const linkedImage = await db.mediaReference.findFirst({
      where: {
        subjectId: product.id,
        subjectType: MediaReferenceSubjectType.PRODUCT,
        assetId: parsed.data.seoOpenGraphImageId,
      },
      select: {
        assetId: true,
      },
    });

    if (!linkedImage) {
      return {
        status: "error",
        message: "L’image Open Graph sélectionnée n’est pas liée à ce produit.",
        fieldErrors: buildFieldErrors({
          seoOpenGraphImageId: "Image non autorisée pour ce produit.",
        }),
      };
    }
  }

  const metaTitle = parsed.data.seoTitle.trim().length > 0 ? parsed.data.seoTitle.trim() : null;
  const metaDescription =
    parsed.data.seoDescription.trim().length > 0 ? parsed.data.seoDescription.trim() : null;
  const canonicalPath =
    parsed.data.seoCanonicalPath !== null && parsed.data.seoCanonicalPath.trim().length > 0
      ? parsed.data.seoCanonicalPath.trim()
      : null;
  const openGraphTitle =
    parsed.data.seoOpenGraphTitle.trim().length > 0 ? parsed.data.seoOpenGraphTitle.trim() : null;
  const openGraphDescription =
    parsed.data.seoOpenGraphDescription.trim().length > 0
      ? parsed.data.seoOpenGraphDescription.trim()
      : null;

  await db.seoMetadata.upsert({
    where: {
      storeId_subjectType_subjectId: {
        storeId: product.storeId,
        subjectType: SeoSubjectType.PRODUCT,
        subjectId: product.id,
      },
    },
    update: {
      metaTitle,
      metaDescription,
      indexingMode: parsed.data.seoIndexingMode,
      sitemapIncluded: parsed.data.seoSitemapIncluded,
      canonicalPath,
      openGraphTitle,
      openGraphDescription,
      openGraphImageId: parsed.data.seoOpenGraphImageId,
    },
    create: {
      storeId: product.storeId,
      subjectType: SeoSubjectType.PRODUCT,
      subjectId: product.id,
      metaTitle,
      metaDescription,
      indexingMode: parsed.data.seoIndexingMode,
      sitemapIncluded: parsed.data.seoSitemapIncluded,
      canonicalPath,
      openGraphTitle,
      openGraphDescription,
      openGraphImageId: parsed.data.seoOpenGraphImageId,
    },
  });

  revalidatePath("/admin/products");
  revalidatePath(`/admin/products/${product.slug}/edit`);

  return {
    status: "success",
    message: "Les informations SEO ont été enregistrées.",
    fieldErrors: {},
  };
}
