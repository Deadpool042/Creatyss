import {
  MediaReferenceRole,
  ProductStatus,
  ProductVariantStatus,
  SeoIndexingMode,
} from "@/prisma-generated/client";

import type { AdminProductEditorData } from "@/features/admin/products/editor/types";

type ProductEditorMediaReferenceSource = {
  role: MediaReferenceRole;
  sortOrder: number;
  isPrimary: boolean;
  asset: {
    id: string;
    publicUrl: string | null;
    altText: string | null;
  };
};

type ProductEditorSource = {
  product: {
    id: string;
    storeId: string;
    slug: string | null;
    name: string;
    shortDescription: string | null;
    description: string | null;
    status: ProductStatus;
    isFeatured: boolean;
    primaryImageId: string | null;
    productCategories: Array<{
      isPrimary: boolean;
      sortOrder: number;
      category: {
        id: string;
        slug: string;
        name: string;
        parent: {
          name: string;
        } | null;
      };
    }>;
    variants: Array<{
      id: string;
      slug: string | null;
      name: string | null;
      sku: string;
      status: ProductVariantStatus;
      primaryImage: {
        publicUrl: string | null;
        altText: string | null;
      } | null;
      prices: Array<{
        amount: { toString(): string };
        compareAtAmount: { toString(): string } | null;
      }>;
    }>;
  };
  mediaReferences: ProductEditorMediaReferenceSource[];
  seoMetadata: {
    metaTitle: string | null;
    metaDescription: string | null;
    canonicalPath: string | null;
    indexingMode: SeoIndexingMode;
    sitemapIncluded: boolean;
    openGraphTitle: string | null;
    openGraphDescription: string | null;
    openGraphImageId: string | null;
  } | null;
};

function decimalToString(value: { toString(): string } | null): string {
  return value ? value.toString() : "";
}

function normalizeText(value: string | null | undefined): string {
  return value?.trim() ?? "";
}

function mapProductStatusToAdminStatus(status: ProductStatus): AdminProductEditorData["status"] {
  if (status === ProductStatus.ACTIVE) {
    return "published";
  }

  if (status === ProductStatus.ARCHIVED) {
    return "archived";
  }

  return "draft";
}

function mapVariantStatusToAdminStatus(
  status: ProductVariantStatus
): AdminProductEditorData["variants"][number]["status"] {
  if (status === ProductVariantStatus.ACTIVE) {
    return "published";
  }

  if (status === ProductVariantStatus.ARCHIVED) {
    return "archived";
  }

  return "draft";
}

function mapSeoIndexingMode(
  indexingMode: SeoIndexingMode | null | undefined
): AdminProductEditorData["seo"]["indexingMode"] {
  if (indexingMode === SeoIndexingMode.INDEX_NOFOLLOW) {
    return "INDEX_NOFOLLOW";
  }

  if (indexingMode === SeoIndexingMode.NOINDEX_FOLLOW) {
    return "NOINDEX_FOLLOW";
  }

  if (indexingMode === SeoIndexingMode.NOINDEX_NOFOLLOW) {
    return "NOINDEX_NOFOLLOW";
  }

  return "INDEX_FOLLOW";
}

function resolveFallbackOpenGraphImageUrl(images: AdminProductEditorData["images"]): string | null {
  const primaryImage = images.find((image) => image.isPrimary && image.url.trim().length > 0);

  if (primaryImage) {
    return primaryImage.url;
  }

  const firstImage = images.find((image) => image.url.trim().length > 0);
  return firstImage ? firstImage.url : null;
}

export function mapProductEditorData(input: ProductEditorSource): AdminProductEditorData {
  const { product, mediaReferences, seoMetadata } = input;

  const categories = product.productCategories.map((item) => ({
    id: item.category.id,
    slug: item.category.slug,
    name: item.category.name,
    parentName: item.category.parent?.name ?? null,
    isPrimary: item.isPrimary,
    sortOrder: item.sortOrder,
  }));

  const categoryIds = categories.map((category) => category.id);
  const primaryCategoryId = categories.find((category) => category.isPrimary)?.id ?? null;

  const images = mediaReferences
    .filter(
      (reference) =>
        reference.role === MediaReferenceRole.GALLERY ||
        reference.role === MediaReferenceRole.PRIMARY
    )
    .map((reference) => ({
      id: reference.asset.id,
      url: reference.asset.publicUrl ?? "",
      alt: reference.asset.altText ?? "",
      isPrimary:
        reference.asset.id === product.primaryImageId ||
        reference.isPrimary ||
        reference.role === MediaReferenceRole.PRIMARY,
      sortOrder: reference.sortOrder,
    }))
    .sort((left, right) => left.sortOrder - right.sortOrder);

  const variants = product.variants.map((variant) => {
    const activePrice = variant.prices[0] ?? null;

    return {
      id: variant.id,
      slug: variant.slug ?? "",
      name: variant.name ?? "",
      sku: variant.sku,
      status: mapVariantStatusToAdminStatus(variant.status),
      amount: decimalToString(activePrice?.amount ?? null),
      compareAtAmount: decimalToString(activePrice?.compareAtAmount ?? null),
      primaryImageUrl: variant.primaryImage?.publicUrl ?? null,
      primaryImageAlt: variant.primaryImage?.altText ?? null,
    };
  });

  const fallbackTitle = normalizeText(product.name);
  const fallbackDescription = normalizeText(product.shortDescription);
  const fallbackCanonicalPath = `/products/${product.slug ?? ""}`;
  const fallbackOpenGraphTitle =
    normalizeText(seoMetadata?.metaTitle).length > 0
      ? normalizeText(seoMetadata?.metaTitle)
      : fallbackTitle;
  const fallbackOpenGraphDescription =
    normalizeText(seoMetadata?.metaDescription).length > 0
      ? normalizeText(seoMetadata?.metaDescription)
      : fallbackDescription;
  const fallbackOpenGraphImageUrl = resolveFallbackOpenGraphImageUrl(images);

  return {
    id: product.id,
    slug: product.slug ?? "",
    name: product.name,
    shortDescription: product.shortDescription ?? "",
    description: product.description ?? "",
    status: mapProductStatusToAdminStatus(product.status),
    isFeatured: product.isFeatured,
    primaryCategoryId,
    categoryIds,
    categories,
    images,
    variants,
    seo: {
      title: seoMetadata?.metaTitle ?? "",
      description: seoMetadata?.metaDescription ?? "",
      canonicalPath: seoMetadata?.canonicalPath ?? null,
      indexingMode: mapSeoIndexingMode(seoMetadata?.indexingMode),
      sitemapIncluded: seoMetadata?.sitemapIncluded ?? true,
      openGraphTitle: seoMetadata?.openGraphTitle ?? "",
      openGraphDescription: seoMetadata?.openGraphDescription ?? "",
      openGraphImageId: seoMetadata?.openGraphImageId ?? null,
      fallbackTitle,
      fallbackDescription,
      fallbackCanonicalPath,
      fallbackOpenGraphTitle,
      fallbackOpenGraphDescription,
      fallbackOpenGraphImageUrl,
    },
  };
}
