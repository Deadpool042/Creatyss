export type ProductSeoFormValues = {
  id: string;
  seoTitle: string;
  seoDescription: string;
  seoIndexingMode: "INDEX_FOLLOW" | "INDEX_NOFOLLOW" | "NOINDEX_FOLLOW" | "NOINDEX_NOFOLLOW";
  seoSitemapIncluded: boolean;
  seoCanonicalPath: string | null;
  seoOpenGraphTitle: string;
  seoOpenGraphDescription: string;
  seoOpenGraphImageId: string | null;
};

export type ProductSeoFormState = {
  status: "idle" | "success" | "error";
  message: string | null;
  fieldErrors: Partial<
    Record<
      | "id"
      | "seoTitle"
      | "seoDescription"
      | "seoIndexingMode"
      | "seoSitemapIncluded"
      | "seoCanonicalPath"
      | "seoOpenGraphTitle"
      | "seoOpenGraphDescription"
      | "seoOpenGraphImageId",
      string
    >
  >;
};

export const productSeoFormInitialState: ProductSeoFormState = {
  status: "idle",
  message: null,
  fieldErrors: {},
};

export type ProductSeoFormAction = (
  prevState: ProductSeoFormState,
  formData: FormData
) => Promise<ProductSeoFormState>;
