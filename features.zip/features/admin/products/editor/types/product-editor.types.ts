export type AdminProductEditorStatus =
  | "draft"
  | "active"
  | "inactive"
  | "archived";

export type AdminRelatedProductEditorType =
  | "related"
  | "cross_sell"
  | "up_sell"
  | "accessory"
  | "similar";

export type AdminProductEditorCategoryLink = {
  id: string;
  categoryId: string;
  categoryName: string;
  categorySlug: string;
  isPrimary: boolean;
  sortOrder: number;
};

export type AdminProductEditorRelatedProduct = {
  id: string;
  targetProductId: string;
  targetProductName: string;
  targetProductSlug: string;
  type: AdminRelatedProductEditorType;
  sortOrder: number;
};

export type AdminProductEditorProduct = {
  id: string;
  slug: string;
  name: string;
  skuRoot: string | null;
  shortDescription: string | null;
  description: string | null;
  status: AdminProductEditorStatus;
  isFeatured: boolean;
  isStandalone: boolean;
  productTypeId: string | null;
  productTypeCode: string | null;
  primaryImageId: string | null;
  primaryImageUrl: string | null;
  primaryImageStorageKey: string | null;
  primaryImageAltText: string | null;
  categoryLinks: AdminProductEditorCategoryLink[];
  relatedProducts: AdminProductEditorRelatedProduct[];
};

export type AdminProductEditorData = {
  product: AdminProductEditorProduct;
  variants: AdminProductVariantListItem[];
  images: AdminProductImageItem[];
};

export type AdminProductVariantStatus =
  | "draft"
  | "active"
  | "inactive"
  | "archived";

export type AdminProductVariantListItem = {
  id: string;
  slug: string | null;
  sku: string;
  name: string | null;
  status: AdminProductVariantStatus;
  isDefault: boolean;
  sortOrder: number;
  barcode: string | null;
  externalReference: string | null;
  weightGrams: string | null;
  widthMm: string | null;
  heightMm: string | null;
  depthMm: string | null;
  primaryImageId: string | null;
  primaryImageUrl: string | null;
  primaryImageStorageKey: string | null;
  primaryImageAltText: string | null;
};

export type AdminProductImageItem = {
  id: string;
  mediaAssetId: string;
  subjectType: "product" | "product_variant";
  subjectId: string;
  role: "gallery" | "thumbnail" | "other";
  sortOrder: number;
  isPrimary: boolean;
  publicUrl: string | null;
  storageKey: string;
  altText: string | null;
  originalName: string | null;
  mimeType: string | null;
};
