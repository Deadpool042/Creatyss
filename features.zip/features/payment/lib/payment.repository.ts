import { db } from "@/core/db";

export type PaymentStatus = "pending" | "succeeded" | "failed";

export type PaymentStartContext = {
  orderId: string;
  reference: string;
  orderStatus: "pending" | "paid" | "preparing" | "shipped" | "cancelled";
  customerEmail: string;
  totalAmount: string;
  paymentStatus: PaymentStatus;
  stripeCheckoutSessionId: string | null;
  stripePaymentIntentId: string | null;
};

type PaymentStartContextRow = {
  order_id: string; reference: string; order_status: string; customer_email: string;
  total_amount: string; payment_status: string; stripe_checkout_session_id: string | null;
  stripe_payment_intent_id: string | null;
};

type PaymentOrderIdRow = { order_id: string };

async function queryFirst<T>(sql: string, params: unknown[] = []): Promise<T | null> {
  const rows = await db.$queryRawUnsafe<T>(sql, ...params);
  return (rows as T[])[0] ?? null;
}

function isValidOrderReference(value: string): boolean {
  return /^CRY-[A-Z0-9]{10}$/.test(value);
}

export async function findPaymentStartContextByOrderReference(
  reference: string
): Promise<PaymentStartContext | null> {
  if (!isValidOrderReference(reference)) return null;
  const row = await queryFirst<PaymentStartContextRow>(
    `select o.id::text as order_id, o.reference, o.status as order_status, o.customer_email,
      o.total_amount::text as total_amount, p.status as payment_status,
      p.stripe_checkout_session_id, p.stripe_payment_intent_id
     from orders o left join payments p on p.order_id = o.id
     where o.reference = $1 limit 1`,
    [reference]
  );
  if (row === null) return null;
  return {
    orderId: row.order_id,
    reference: row.reference,
    orderStatus: row.order_status as PaymentStartContext["orderStatus"],
    customerEmail: row.customer_email,
    totalAmount: row.total_amount,
    paymentStatus: (row.payment_status ?? "pending") as PaymentStatus,
    stripeCheckoutSessionId: row.stripe_checkout_session_id,
    stripePaymentIntentId: row.stripe_payment_intent_id,
  };
}

export async function saveStripeCheckoutSessionForOrder(input: {
  orderId: string; stripeCheckoutSessionId: string; stripePaymentIntentId: string | null;
}): Promise<void> {
  await db.$executeRawUnsafe(
    `insert into payments (order_id, provider, method, status, amount, currency,
      stripe_checkout_session_id, stripe_payment_intent_id)
     select $1::bigint, 'stripe', 'card', 'pending', total_amount, 'eur', $2, $3
     from orders where id = $1::bigint
     on conflict (order_id) do update set
       status = 'pending',
       stripe_checkout_session_id = excluded.stripe_checkout_session_id,
       stripe_payment_intent_id = excluded.stripe_payment_intent_id`,
    input.orderId, input.stripeCheckoutSessionId, input.stripePaymentIntentId
  );
}

export async function markPaymentSucceededByCheckoutSessionId(input: {
  stripeCheckoutSessionId: string; stripePaymentIntentId: string | null;
}): Promise<string | null> {
  return db.$transaction(
    async (tx) => {
      const rows = await tx.$queryRawUnsafe<Array<{ id: string; order_id: string; status: string; order_status: string }>>(
        `select p.id::text as id, p.order_id::text as order_id, p.status, o.status as order_status
         from payments p inner join orders o on o.id = p.order_id
         where p.stripe_checkout_session_id = $1 limit 1 for update of p`,
        input.stripeCheckoutSessionId
      );
      const row = rows[0] ?? null;
      if (row === null) return null;

      if (row.status !== "succeeded") {
        await tx.$executeRawUnsafe(
          `update payments set status = 'succeeded'${input.stripePaymentIntentId !== null ? ", stripe_payment_intent_id = $2" : ""}
           where id = $1::bigint`,
          row.id, ...(input.stripePaymentIntentId !== null ? [input.stripePaymentIntentId] : [])
        );
      }

      if (row.order_status === "pending") {
        await tx.$executeRawUnsafe(`update orders set status = 'paid' where id = $1::bigint`, row.order_id);
      }

      return row.order_id;
    },
    { isolationLevel: "Serializable" }
  );
}

export async function markPaymentFailedByCheckoutSessionId(input: {
  stripeCheckoutSessionId: string; stripePaymentIntentId: string | null;
}): Promise<void> {
  await db.$transaction(
    async (tx) => {
      const rows = await tx.$queryRawUnsafe<Array<{ id: string; status: string }>>(
        `select id::text as id, status from payments where stripe_checkout_session_id = $1 limit 1 for update`,
        input.stripeCheckoutSessionId
      );
      const row = rows[0] ?? null;
      if (row === null) return;

      if (row.status !== "succeeded") {
        await tx.$executeRawUnsafe(
          `update payments set status = 'failed'${input.stripePaymentIntentId !== null ? ", stripe_payment_intent_id = $2" : ""}
           where id = $1::bigint`,
          row.id, ...(input.stripePaymentIntentId !== null ? [input.stripePaymentIntentId] : [])
        );
      }
    },
    { isolationLevel: "Serializable" }
  );
}
